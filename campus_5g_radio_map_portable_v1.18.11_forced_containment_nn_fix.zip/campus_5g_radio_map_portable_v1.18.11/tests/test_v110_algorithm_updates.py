from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent))
    sys.modules[name] = module
    try:
        assert spec.loader is not None
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


def test_profiled_pathloss_recovers_synthetic_parameters():
    m = _load(ROOT / "workflows/localization/run_27stations_sparse_localization_v2.py", "loc_v110_profile")
    d = np.linspace(40.0, 260.0, 20)
    truth_n, truth_b = 2.65, -21.0
    y = truth_b - 10.0 * truth_n * np.log10(d)
    n, b, residual = m._profile_pathloss_parameters(d, y, residual_scale_db=6.0)
    assert abs(n - truth_n) < 0.12
    assert abs(b - truth_b) < 1.5
    assert np.nanmax(np.abs(residual)) < 1.0


def test_geometry_filtered_random_is_seeded_and_reports_quality():
    m = _load(ROOT / "workflows/localization/run_27stations_sparse_localization_v2.py", "loc_v110_random")
    rng = np.random.default_rng(5)
    n = 80
    points = pd.DataFrame({
        "x_m": rng.uniform(-200, 200, n),
        "y_m": rng.uniform(-150, 150, n),
        "rsrp_s1": rng.normal(-80, 4, n),
        "rsrp_s2": rng.normal(-82, 4, n),
        "rsrp_s3": rng.normal(-84, 4, n),
    })
    a, _ = m.select_random_localization_points(points, 12, 1001, False)
    b, _ = m.select_random_localization_points(points, 12, 1001, False)
    assert a[["x_m", "y_m"]].equals(b[["x_m", "y_m"]])
    assert (a["selection_mode"] == "random").all()
    assert (a["selection_strategy"] == "geometry_filtered_top_quartile").all()
    assert np.isfinite(float(a["random_subset_geometry_score"].iloc[0]))


def test_coverage_ranking_reduces_measured_pool_gap_against_random_prefix():
    m = _load(ROOT / "workflows/reconstruction/run_reconstruction.py", "recon_v110_cov")
    xs = np.linspace(0, 100, 11)
    ys = np.linspace(0, 100, 11)
    xy = np.asarray([(x, y) for x in xs for y in ys], dtype=float)
    measured = pd.DataFrame({"x_m": xy[:, 0], "y_m": xy[:, 1], "measured_rsrp_dbm": -80.0})
    x_axis = np.arange(0.0, 101.0, 2.0)
    y_axis = np.arange(0.0, 101.0, 2.0)
    mask = np.ones((len(y_axis), len(x_axis)), dtype=bool)
    ranked = m.coverage_aware_nested_ranking(measured, x_axis, y_axis, mask, max_count=15)
    rng = np.random.default_rng(77)
    random_idx = rng.permutation(len(measured))[:15]
    all_xy = measured[["x_m", "y_m"]].to_numpy(float)
    d_cov, _ = cKDTree(ranked[["x_m", "y_m"]].to_numpy(float)).query(all_xy, k=1)
    d_rand, _ = cKDTree(all_xy[random_idx]).query(all_xy, k=1)
    assert np.percentile(d_cov, 90) < np.percentile(d_rand, 90)
    assert int(ranked["coverage_rank"].iloc[-1]) == 15


def test_mean_prediction_ensemble_summary():
    m = _load(ROOT / "workflows/localization/run_27stations_localization_multicount.py", "loc_v110_ensemble")
    frame = pd.DataFrame({
        "point_count": [10, 10, 10],
        "error_of_mean_prediction_m": [10.0, 20.0, 30.0],
    })
    out = m.summarize_mean_prediction_ensemble(frame)
    assert np.isclose(float(out.loc[0, "mean_error_m"]), 20.0)
    assert np.isclose(float(out.loc[0, "rmse_m"]), np.sqrt((100+400+900)/3))
