from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
LOC_ROOT = ROOT / "workflows" / "localization"
if str(LOC_ROOT) not in sys.path:
    sys.path.insert(0, str(LOC_ROOT))
MODULE_PATH = LOC_ROOT / "run_27stations_sparse_localization_v2.py"
SPEC = importlib.util.spec_from_file_location("five_point_localization", MODULE_PATH)
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = MOD
SPEC.loader.exec_module(MOD)


def test_five_point_sector_display_draws_three_dashed_calibrated_rays():
    fig, ax = plt.subplots()
    MOD._draw_calibrated_sector_rays(
        ax,
        origin_xy=np.array([100.0, 200.0]),
        alphas_rad=[0.0, 2.0 * np.pi / 3.0, 4.0 * np.pi / 3.0],
        xlim=(0.0, 500.0),
        ylim=(0.0, 500.0),
    )
    assert len(ax.lines) == 3
    assert all(line.get_linestyle() == "--" for line in ax.lines)
    assert all(np.allclose(line.get_xydata()[0], [100.0, 200.0]) for line in ax.lines)
    assert ax.lines[0].get_label() == "Calibrated sector directions"
    plt.close(fig)
