from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LOC = ROOT / "workflows" / "localization"
if str(LOC) not in sys.path:
    sys.path.insert(0, str(LOC))


def _load_single():
    path = LOC / "run_27stations_sparse_localization_v2.py"
    spec = importlib.util.spec_from_file_location("loc_v16_single", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_strict_nested_selection_does_not_switch_candidate_pool():
    m = _load_single()
    rng = np.random.default_rng(55)
    n = 60
    xy = rng.uniform(-260, 260, size=(n, 2))
    frame = pd.DataFrame({
        "x_m": xy[:, 0], "y_m": xy[:, 1],
        "rsrp_s1": rng.uniform(-100, -65, n),
        "rsrp_s2": rng.uniform(-105, -70, n),
        "rsrp_s3": rng.uniform(-110, -72, n),
    })
    # Only 11 complete-sector points. v1.4 changed pools at k=12; v1.6 must not.
    frame.loc[11:, "rsrp_s3"] = np.nan
    train10, _ = m.select_balanced_strong_points(frame, 10, 99, False, ranking_k=15)
    train12, _ = m.select_balanced_strong_points(frame, 12, 99, False, ranking_k=15)
    train15, _ = m.select_balanced_strong_points(frame, 15, 99, False, ranking_k=15)
    assert np.allclose(train10[["x_m", "y_m"]], train12.iloc[:10][["x_m", "y_m"]])
    assert np.allclose(train12[["x_m", "y_m"]], train15.iloc[:12][["x_m", "y_m"]])


def test_omni_solution_is_not_hard_locked_to_anchor():
    m = _load_single()
    rng = np.random.default_rng(7)
    tx = np.array([40.0, -30.0])
    angles = np.linspace(0.0, 2.0 * np.pi, 12, endpoint=False)
    radii = np.linspace(55.0, 190.0, 12)
    xy = tx + np.column_stack([np.cos(angles), np.sin(angles)]) * radii[:, None]
    d = np.sqrt(np.sum((xy - tx) ** 2, axis=1) + m.TX_RX_VERTICAL_SEPARATION_M ** 2)
    rsrp = -20.0 - 27.0 * np.log10(d) + rng.normal(0, 0.4, size=len(d))
    selected = pd.DataFrame({
        "x_m": xy[:, 0], "y_m": xy[:, 1],
        "rsrp_s1": rsrp, "rsrp_s2": np.nan, "rsrp_s3": np.nan,
    })
    anchor = np.array([-30.0, 55.0])
    result = m.optimize_station(
        selected=selected, station_id=22, omni=True, anchor=anchor,
        direction_row=None, direction_mode="fixed",
        global_bounds=(-400, 400, -400, 400), seed=123,
        de_maxiter=8, de_popsize=5,
    )
    assert 0.88 <= result["model_weight"] <= 0.92
    assert not np.allclose(result["final_xy"], anchor)
    assert result["model_anchor_disagreement_m"] >= 0.0
