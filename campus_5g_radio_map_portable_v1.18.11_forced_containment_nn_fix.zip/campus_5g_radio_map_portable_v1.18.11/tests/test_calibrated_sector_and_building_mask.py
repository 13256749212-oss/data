from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LOC_ROOT = ROOT / "workflows" / "localization"
RECON_ROOT = ROOT / "workflows" / "reconstruction"
for path in (LOC_ROOT, RECON_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

loc_path = LOC_ROOT / "all_pci_cluster_localization.py"
spec = importlib.util.spec_from_file_location("all_pci_calibrated", loc_path)
loc = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = loc
spec.loader.exec_module(loc)

recon_path = RECON_ROOT / "run_reconstruction.py"
spec2 = importlib.util.spec_from_file_location("recon_multicount", recon_path)
recon = importlib.util.module_from_spec(spec2)
assert spec2 and spec2.loader
sys.modules[spec2.name] = recon
spec2.loader.exec_module(recon)


def test_all_pci_sector_display_uses_best_parameter_alphas(tmp_path: Path):
    cal_root = tmp_path / "outputs" / "parameter_calibration"
    station_dir = cal_root / "station_3"
    station_dir.mkdir(parents=True)
    alphas = [0.1, 2.2, -1.95]
    (station_dir / "best_parameters.json").write_text(
        json.dumps({"alphas_rad": alphas}), encoding="utf-8"
    )
    sector_map = pd.DataFrame(
        {"pci": [558, 559, 560], "sector_index": [1, 2, 3]}
    )
    result, source = loc._load_calibrated_sector_angles(
        project_root=tmp_path,
        calibration_root=None,
        station_id=3,
        sector_map=sector_map,
        is_omni=False,
    )
    assert source.endswith("station_3/best_parameters.json")
    assert np.isclose(result[558], alphas[0])
    assert np.isclose(result[559], alphas[1])
    assert np.isclose(result[560], alphas[2])


def test_prior_building_mask_can_be_resampled_to_reconstruction_grid():
    prior = SimpleNamespace(
        building_mask=np.asarray([[False, True], [False, True]], dtype=bool),
        x_axis_m=np.asarray([0.5, 1.5], dtype=float),
        y_axis_m=np.asarray([0.5, 1.5], dtype=float),
    )
    x = np.asarray([0.5, 1.0, 1.5], dtype=float)
    y = np.asarray([0.5, 1.0, 1.5], dtype=float)
    mask = recon._resample_prior_building_mask(prior, x, y)
    assert mask.shape == (3, 3)
    assert int(mask.sum()) > 0
    assert mask[:, -1].all()
