from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"
RECON_DIR = MOD.parent
if str(RECON_DIR) not in sys.path:
    sys.path.insert(0, str(RECON_DIR))


def _load():
    spec = importlib.util.spec_from_file_location("recon_v11811", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _sharp_transition_frame(nx: int = 32, ny: int = 20) -> pd.DataFrame:
    gx, gy = np.meshgrid(np.arange(nx, dtype=float), np.arange(ny, dtype=float))
    keep = ((gy.astype(int) % 3) == 0) | ((gx.astype(int) % 6) == 0)
    x_idx = gx[keep].ravel()
    y_idx = gy[keep].ravel()
    x = 10.0 * x_idx
    y = 10.0 * y_idx
    rsrp = -82.0 + 0.045 * x - 0.035 * y + 3.0 * np.sin(x / 40.0)
    # Strong region creates an observed jump only after the corresponding point
    # has actually been selected.  Unselected labels remain inaccessible.
    rsrp[(x > 240.0) & (y < 80.0)] += 35.0
    return pd.DataFrame({
        "x_m": x,
        "y_m": y,
        "measured_rsrp_dbm": rsrp,
        "ix": x_idx.astype(int),
        "iy": y_idx.astype(int),
    })


def test_high_jump_forces_immediate_containment_when_budget_remains():
    r = _load()
    frame = _sharp_transition_frame()
    n = len(frame)
    counts = [max(3, int(np.ceil(n * p / 100.0))) for p in (2, 4, 6, 8, 10, 12, 14, 16, 18, 20)]
    ranked, _ = r.voronoi_safe_adaptive_nested_ranking(
        frame,
        np.arange(32, dtype=float) * 10.0,
        np.arange(20, dtype=float) * 10.0,
        np.ones((20, 32), dtype=bool),
        stage_target_counts=counts,
    )
    modes = ranked["selection_mode_at_acquisition"].tolist()
    jumps = ranked["observed_jump_from_previous_controller_db"].to_numpy(float)
    # At least one strong observed jump must be followed immediately by forced
    # containment rather than another ordinary coverage transition.
    strong = np.where(jumps >= 15.0)[0]
    assert len(strong) >= 1
    assert any(i + 1 < len(modes) and modes[i + 1] == "forced_voronoi_containment" for i in strong)


def test_forced_containment_still_has_no_forbidden_information_access():
    src = MOD.read_text(encoding="utf-8")
    start = src.index("def voronoi_safe_adaptive_nested_ranking(")
    end = src.index("\ndef _domain_support_xy(", start)
    body = src[start:end]
    assert "reference_map" not in body
    assert "simulation_prior" not in body
    assert "rmse(" not in body.lower()
    assert "forced_voronoi_containment" in body
    assert '"selection_uses_unselected_measured_rsrp": False' in body
    assert '"selection_uses_reference_rsrp": False' in body
    assert '"selection_uses_simulation_rsrp": False' in body
    assert '"selection_uses_final_rmse": False' in body
