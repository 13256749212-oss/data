from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "workflows" / "localization" / "run_27stations_multicandidate_cv_localization.py"


def _load():
    spec = importlib.util.spec_from_file_location("pn_mcvl_v115_test", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.path.insert(0, str(SCRIPT.parent))
    sys.modules["pn_mcvl_v115_test"] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


def _pool(n: int = 40) -> pd.DataFrame:
    i = np.arange(n)
    return pd.DataFrame({
        "x_m": i.astype(float),
        "y_m": (2 * i).astype(float),
        "z_m": np.full(n, 1.5),
        "rsrp_s1": np.where(i % 2 == 0, -80.0, -85.0),
        "rsrp_s2": np.where(i % 3 == 0, -82.0, np.nan),
        "rsrp_s3": np.where(i % 5 == 0, -84.0, np.nan),
    })


def _synthetic(m, tx: np.ndarray, angles: np.ndarray, n: int = 15) -> pd.DataFrame:
    rng = np.random.default_rng(7)
    rows = []
    for i in range(n):
        theta = angles[i % 3] + rng.normal(0.0, 0.35)
        r = rng.uniform(90.0, 260.0)
        p = tx + r * np.array([np.cos(theta), np.sin(theta)]) + rng.normal(0.0, 5.0, 2)
        bearing = np.arctan2(p[1] - tx[1], p[0] - tx[0])
        d = np.sqrt(np.sum((p - tx) ** 2) + m.VERTICAL_SEPARATION_M ** 2)
        row = {"x_m": p[0], "y_m": p[1], "z_m": 1.5, "selection_rank": i + 1}
        for j, a in enumerate(angles, 1):
            gain = m.sector_gain_db(np.array([bearing - a]))[0]
            row[f"rsrp_s{j}"] = -25.0 - 27.0 * np.log10(d) + gain + rng.normal(0.0, 1.5)
            row[f"pci_s{j}"] = 500 + j
        rows.append(row)
    return pd.DataFrame(rows)


def test_nested_random_prefix_10_to_15():
    m = _load()
    df = _pool()
    p10 = m.random_points(df, 10, 12345)
    p11 = m.random_points(df, 11, 12345)
    p15 = m.random_points(df, 15, 12345)
    assert np.allclose(p10[["x_m", "y_m"]].to_numpy(), p11.iloc[:10][["x_m", "y_m"]].to_numpy())
    assert np.allclose(p10[["x_m", "y_m"]].to_numpy(), p15.iloc[:10][["x_m", "y_m"]].to_numpy())
    assert np.allclose(p11[["x_m", "y_m"]].to_numpy(), p15.iloc[:11][["x_m", "y_m"]].to_numpy())


def test_progressive_hysteresis_can_retain_previous_solution_without_truth():
    m = _load()
    tx = np.array([40.0, -20.0])
    angles = np.array([0.0, 2 * np.pi / 3, -2 * np.pi / 3])
    df = _synthetic(m, tx, angles, n=13)
    previous = np.array([55.0, -30.0])
    # Deliberately huge threshold: regardless of the new unconstrained candidate,
    # the truth-free hysteresis must retain the inherited estimate.
    sol = m.solve(
        df, angles, True, False, (-600, 600, -600, 600),
        previous_xy=previous,
        progressive_min_improvement_db=1e6,
    )
    assert sol["solver_mode"] == "progressive_nested_mcvl"
    assert sol["progressive_update_accepted"] is False
    assert np.allclose(sol["final_xy"], previous)


def test_progressive_solver_does_not_require_truth_fields():
    m = _load()
    tx = np.array([20.0, 10.0])
    angles = np.array([0.0, 2 * np.pi / 3, -2 * np.pi / 3])
    df = _synthetic(m, tx, angles, n=12)
    sol = m.solve(
        df, angles, True, False, (-500, 500, -500, 500),
        previous_xy=np.array([30.0, 5.0]),
        progressive_min_improvement_db=0.25,
    )
    assert "true_x_m" not in sol and "true_y_m" not in sol
    assert np.isfinite(sol["final_xy"]).all()
    assert "previous_candidate_score" in sol
    assert "progressive_score_improvement_db" in sol


def test_progressive_trajectory_fusion_is_truth_independent():
    # Load the multicount module because the progressive trajectory fusion lives there.
    batch_script = ROOT / "workflows" / "localization" / "run_27stations_localization_multicount.py"
    spec = importlib.util.spec_from_file_location("pn_mcvl_batch_v115_test", batch_script)
    batch = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules["pn_mcvl_batch_v115_test"] = batch
    spec.loader.exec_module(batch)

    rows = []
    for count in [10, 11, 12]:
        for trial in [1, 2, 3]:
            rows.append({
                "station_id": 3,
                "point_count": count,
                "trial_index": trial,
                "predicted_x_m": 100.0 + 0.5 * trial + 0.1 * count,
                "predicted_y_m": 200.0 - 0.2 * trial,
                "true_x_m": 100.0,
                "true_y_m": 200.0,
            })
    frame = pd.DataFrame(rows)
    _, station_a, _ = batch.build_progressive_trajectory_ensemble(frame)
    shifted = frame.copy()
    shifted["true_x_m"] = 5000.0
    shifted["true_y_m"] = -4000.0
    _, station_b, _ = batch.build_progressive_trajectory_ensemble(shifted)
    assert np.allclose(station_a["progressive_predicted_x_m"], station_b["progressive_predicted_x_m"])
    assert np.allclose(station_a["progressive_predicted_y_m"], station_b["progressive_predicted_y_m"])
