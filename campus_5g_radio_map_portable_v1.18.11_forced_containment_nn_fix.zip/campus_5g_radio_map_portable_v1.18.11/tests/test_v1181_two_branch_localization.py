from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "workflows" / "localization" / "run_27stations_two_branch_localization.py"


def _load():
    spec = importlib.util.spec_from_file_location("two_branch_loc_v1181_test", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.path.insert(0, str(SCRIPT.parent))
    sys.modules["two_branch_loc_v1181_test"] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


def test_formal_table_has_only_two_requested_metrics_plus_point_count():
    m = _load()
    measured = pd.DataFrame({
        "point_count": [10, 10, 11, 11],
        "station_id": [1, 2, 1, 2],
        "horizontal_error_m": [3.0, 4.0, 2.0, 2.0],
    })
    joint = pd.DataFrame({
        "point_count": [10, 10, 11, 11],
        "station_id": [1, 2, 1, 2],
        "horizontal_error_m": [2.0, 2.0, 1.0, 1.0],
    })
    table = m.build_formal_rmse_table(measured, joint, [10, 11])
    assert list(table.columns) == [
        "Receiver locations per station",
        "Measurement-only RMSE (m)",
        "Measurement–simulation RMSE (m)",
    ]
    assert np.isclose(table.loc[0, "Measurement-only RMSE (m)"], np.sqrt((9 + 16) / 2))
    assert np.isclose(table.loc[0, "Measurement–simulation RMSE (m)"], 2.0)


def test_progressive_fusion_does_not_use_truth_to_form_predictions():
    m = _load()
    rows = []
    for count in (10, 11, 12):
        for trial in (1, 2, 3):
            rows.append({
                "station_id": 3,
                "trial_index": trial,
                "point_count": count,
                "predicted_x_m": 100 + trial + 0.1 * count,
                "predicted_y_m": 200 - trial + 0.2 * count,
                "true_x_m": 10.0,
                "true_y_m": 20.0,
            })
    a = m._progressive_station_estimates(pd.DataFrame(rows))
    shifted = pd.DataFrame(rows)
    shifted["true_x_m"] = 5000.0
    shifted["true_y_m"] = -3000.0
    b = m._progressive_station_estimates(shifted)
    assert np.allclose(a["predicted_x_m"], b["predicted_x_m"])
    assert np.allclose(a["predicted_y_m"], b["predicted_y_m"])


def test_counts_parser_is_positive_and_sorted():
    m = _load()
    assert m.parse_counts("15,10,12,10", None) == [10, 12, 15]
    assert m.parse_counts(None, 9) == [9]
