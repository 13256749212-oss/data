from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
LOC=ROOT/'workflows'/'localization'
if str(LOC) not in sys.path: sys.path.insert(0,str(LOC))

def load_mod():
    path=LOC/'run_27stations_sparse_localization_v2.py'
    spec=importlib.util.spec_from_file_location('loc_v18_final',path)
    m=importlib.util.module_from_spec(spec); assert spec.loader is not None
    sys.modules[spec.name]=m; spec.loader.exec_module(m); return m

def frame_from_xy(xy):
    n=len(xy)
    return pd.DataFrame({'x_m':xy[:,0],'y_m':xy[:,1],
        'rsrp_s1':np.linspace(-70,-90,n),'rsrp_s2':np.linspace(-75,-95,n),'rsrp_s3':np.linspace(-80,-100,n)})

def test_geometry_diagnostics_distinguish_surrounding_from_one_sided():
    m=load_mod()
    a=np.linspace(0,2*np.pi,12,endpoint=False)
    around=np.c_[100*np.cos(a),100*np.sin(a)]
    d1=m.geometry_diagnostics(np.array([0.,0.]),frame_from_xy(around),False)
    assert d1['angular_coverage_deg'] > 300
    assert d1['inside_measurement_convex_hull']
    one=np.c_[np.linspace(50,220,12), np.linspace(-20,20,12)]
    d2=m.geometry_diagnostics(np.array([0.,0.]),frame_from_xy(one),False)
    assert d2['angular_coverage_deg'] < d1['angular_coverage_deg']
    assert d2['geometry_reliability_score'] < d1['geometry_reliability_score']

def test_multistart_centers_are_measurement_only_and_unique():
    m=load_mod(); rng=np.random.default_rng(18)
    xy=rng.uniform(-100,100,(15,2)); f=frame_from_xy(xy); anchor=np.array([20.,30.])
    centers=m.multistart_search_centers(f,anchor,False)
    assert centers[0][0]=='strong_anchor'
    assert len(centers)>=2
    vals=[c for _,c in centers]
    for i in range(len(vals)):
        for j in range(i): assert np.linalg.norm(vals[i]-vals[j]) >= 19.999

def test_robust_wrapper_selects_best_candidate_without_truth(monkeypatch):
    m=load_mod()
    xy=np.c_[np.linspace(60,220,12), np.linspace(-15,15,12)]
    selected=frame_from_xy(xy); anchor=np.array([0.,0.])
    calls=[]
    def fake_opt(selected, station_id, omni, anchor, direction_row, direction_mode, global_bounds,
                 seed, de_maxiter, de_popsize, search_center=None):
        c=np.asarray(anchor if search_center is None else search_center,float); calls.append(c.copy())
        if np.linalg.norm(c-anchor)<1e-6:
            model=np.array([180.,180.]); obj=10.0
        else:
            model=c.copy(); obj=5.0
        return {'final_xy':model,'model_xy':model,'anchor':np.asarray(anchor,float),'model_weight':0.93,
                'model_anchor_disagreement_m':float(np.linalg.norm(model-anchor)),
                'optimizer_boundary_margin_m':50.0,'params':np.array([*model,0.8,2.7,-22.]),
                'sign':1,'alpha':0.0,'objective':obj,'direction_prior_used':True,'direction_fit_rms_deg':10.0}
    monkeypatch.setattr(m,'optimize_station',fake_opt)
    out=m.optimize_station_robust(selected,3,False,anchor,None,'fixed',(-500,500,-500,500),18,20,5)
    assert out['multistart_triggered']
    assert out['multistart_candidate_count'] >= 2
    assert out['multistart_selected_label'] != 'strong_anchor'
    assert 'geometry_diagnostics' in out

def test_v18_quality_fields_are_declared():
    m=load_mod(); fields=set(m.ResultRow.__dataclass_fields__)
    required={'angular_coverage_deg','max_angular_gap_deg','inside_measurement_convex_hull',
              'extrapolation_ratio','pci_spatial_balance','geometry_reliability_score',
              'multistart_triggered','multistart_candidate_count','multistart_selected_label'}
    assert required <= fields
    assert ('DP-PGRSL-v1.8' in m.ALGORITHM_NAME) or ('DP-PPRSL-v1.10' in m.ALGORITHM_NAME)
