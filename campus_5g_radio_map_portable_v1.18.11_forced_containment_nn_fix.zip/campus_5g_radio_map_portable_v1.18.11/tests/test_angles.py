import math

import numpy as np

from src.angles import (
    apply_common_azimuth_offset,
    direction_vector,
    downtilt_to_sionna_beta_rad,
    validate_sector_spacing,
)


def test_station3_spacing_and_common_rotation():
    base = (-0.4557757326815798, -2.550170835074775, 1.6386193697116156)
    validate_sector_spacing(base, tolerance_deg=1.0)
    rotated = apply_common_azimuth_offset(base, 35.0)
    gaps = validate_sector_spacing(rotated, tolerance_deg=1.0)
    assert np.allclose(gaps, 120.0, atol=1e-8)


def test_positive_beta_points_down():
    beta = downtilt_to_sionna_beta_rad(12.0)
    direction = direction_vector(0.0, beta)
    assert math.isclose(beta, math.radians(12.0))
    assert direction[2] < 0.0


def test_negative_beta_is_uptilt():
    beta = downtilt_to_sionna_beta_rad(-3.0)
    assert direction_vector(0.0, beta)[2] > 0.0
