from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "workflows" / "localization" / "run_27stations_localization_multicount.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("mcvl_rc_v114_test", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules["mcvl_rc_v114_test"] = module
    spec.loader.exec_module(module)
    return module


def _frame_with_one_far_outlier() -> pd.DataFrame:
    rows = []
    # Nine consistent estimates near (100, 200), one extreme drift estimate.
    xy = [
        (99.0, 201.0), (101.0, 199.0), (102.0, 200.0), (98.0, 200.0),
        (100.0, 202.0), (100.0, 198.0), (101.5, 201.0), (98.5, 199.0),
        (100.5, 200.5), (700.0, -500.0),
    ]
    for trial, (x, y) in enumerate(xy, 1):
        rows.append({
            "point_count": 13,
            "station_id": 3,
            "station_label": "test",
            "trial_index": trial,
            "predicted_x_m": x,
            "predicted_y_m": y,
            "true_x_m": 100.0,
            "true_y_m": 200.0,
            "horizontal_error_m": float(np.hypot(x - 100.0, y - 200.0)),
        })
    return pd.DataFrame(rows)


def test_robust_consensus_rejects_far_trial_without_truth_use():
    m = _load_module()
    frame = _frame_with_one_far_outlier()
    result = m.build_robust_consensus(frame, mad_z=2.0, min_inlier_fraction=0.60, min_scale_m=5.0)
    assert len(result) == 1
    row = result.iloc[0]
    assert int(row["outlier_trial_count"]) >= 1
    assert "10" in str(row["rejected_trial_indices"])
    assert abs(float(row["consensus_predicted_x_m"]) - 100.0) < 3.0
    assert abs(float(row["consensus_predicted_y_m"]) - 200.0) < 3.0


def test_consensus_selection_is_independent_of_ground_truth():
    m = _load_module()
    frame = _frame_with_one_far_outlier()
    first = m.build_robust_consensus(frame, mad_z=2.0, min_inlier_fraction=0.60, min_scale_m=5.0)
    shifted_truth = frame.copy()
    shifted_truth["true_x_m"] = 5000.0
    shifted_truth["true_y_m"] = -3000.0
    second = m.build_robust_consensus(shifted_truth, mad_z=2.0, min_inlier_fraction=0.60, min_scale_m=5.0)
    assert float(first.loc[0, "consensus_predicted_x_m"]) == float(second.loc[0, "consensus_predicted_x_m"])
    assert float(first.loc[0, "consensus_predicted_y_m"]) == float(second.loc[0, "consensus_predicted_y_m"])
    assert first.loc[0, "inlier_trial_indices"] == second.loc[0, "inlier_trial_indices"]
    assert first.loc[0, "rejected_trial_indices"] == second.loc[0, "rejected_trial_indices"]


def test_consensus_summary_has_expected_metrics():
    m = _load_module()
    frame = _frame_with_one_far_outlier()
    consensus = m.build_robust_consensus(frame)
    summary = m.summarize_robust_consensus(consensus)
    assert int(summary.loc[0, "point_count"]) == 13
    assert np.isfinite(float(summary.loc[0, "rmse_m"]))
    assert "PN-MCVL-RC-v1.15" in str(summary.loc[0, "algorithm"])
