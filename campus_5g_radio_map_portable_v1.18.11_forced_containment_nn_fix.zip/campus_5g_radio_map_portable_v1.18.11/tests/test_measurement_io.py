from pathlib import Path

import pandas as pd

from src.measurement_io import read_measurements


def test_long_format(tmp_path: Path):
    path = tmp_path / "m.csv"
    pd.DataFrame(
        {"x_m": [1.0], "y_m": [2.0], "pci": [558], "rsrp_dbm": [-80.5]}
    ).to_csv(path, index=False)
    out = read_measurements(path)
    assert len(out) == 1
    assert int(out.iloc[0]["pci"]) == 558


def test_multi_value_fields(tmp_path: Path):
    path = tmp_path / "m.csv"
    pd.DataFrame(
        {"x_m": [1.0], "y_m": [2.0], "NR5G PCI": ["558;559"], "NR5G SS RSRP": ["-80.5;-91.0"]}
    ).to_csv(path, index=False)
    out = read_measurements(path)
    assert sorted(out["pci"].tolist()) == [558, 559]
