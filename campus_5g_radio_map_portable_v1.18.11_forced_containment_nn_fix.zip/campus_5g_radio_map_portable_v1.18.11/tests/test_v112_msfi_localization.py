from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def _load():
    path=ROOT/'workflows/localization/run_27stations_multisector_field_localization.py'
    spec=importlib.util.spec_from_file_location('msfi_v112_test',path)
    m=importlib.util.module_from_spec(spec); sys.path.insert(0,str(path.parent)); sys.modules['msfi_v112_test']=m
    try: spec.loader.exec_module(m)
    finally: sys.path.pop(0)
    return m

def test_random_points_uniform_seeded():
    m=_load(); n=30
    df=pd.DataFrame({'x_m':np.arange(n,dtype=float),'y_m':np.arange(n,dtype=float),'z_m':1.5,
        'rsrp_s1':np.where(np.arange(n)%2==0,-80.,np.nan),'rsrp_s2':np.where(np.arange(n)%3==0,-82.,np.nan),'rsrp_s3':np.where(np.arange(n)%5==0,-84.,np.nan)})
    a=m.random_points(df,10,123); b=m.random_points(df,10,123); c=m.random_points(df,10,124)
    assert a[['x_m','y_m']].equals(b[['x_m','y_m']])
    assert not a[['x_m','y_m']].equals(c[['x_m','y_m']])
    assert len(a)==10 and a[['rsrp_s1','rsrp_s2','rsrp_s3']].notna().any(axis=1).all()

def test_msfi_recovers_synthetic_three_sector_site():
    m=_load(); tx=np.array([50.,-30.]); angles=np.array([0.,2*np.pi/3,-2*np.pi/3]); rng=np.random.default_rng(4)
    rows=[]
    for i in range(15):
        sector=i%3; theta=angles[sector]+rng.normal(0,0.4); r=rng.uniform(80,300)
        p=tx+r*np.array([np.cos(theta),np.sin(theta)])+rng.normal(0,8,2)
        bearing=np.arctan2(p[1]-tx[1],p[0]-tx[0]); d=np.sqrt(np.sum((p-tx)**2)+28.5**2)
        row={'x_m':p[0],'y_m':p[1],'z_m':1.5,'selection_rank':i+1}
        for j,a in enumerate(angles,1):
            gain=m.sector_gain_db(np.array([bearing-a]))[0]
            row[f'rsrp_s{j}']=-25-27*np.log10(d)+gain+rng.normal(0,2); row[f'pci_s{j}']=500+j
        rows.append(row)
    df=pd.DataFrame(rows)
    sol=m.solve(df,angles,True,False,(-600,600,-600,600))
    assert sol['solver_mode']=='multi_sector_spatial_field_intersection'
    assert sol['field_count']==3
    assert np.isfinite(sol['final_xy']).all()
    assert np.linalg.norm(sol['final_xy']-tx)<40.0

def test_msfi_no_joint_pathloss_parameters_in_solution():
    m=_load(); angles=np.array([0.,2*np.pi/3,-2*np.pi/3]); rng=np.random.default_rng(9)
    rows=[]
    for i in range(12):
        p=np.array([100.+10*i,-100.+18*i]); bearing=np.arctan2(p[1],p[0]); d=np.sqrt(np.sum(p*p)+28.5**2)
        row={'x_m':p[0],'y_m':p[1],'z_m':1.5,'selection_rank':i+1}
        for j,a in enumerate(angles,1):
            row[f'rsrp_s{j}']=-25-27*np.log10(d)+m.sector_gain_db(np.array([bearing-a]))[0]+rng.normal(0,1); row[f'pci_s{j}']=600+j
        rows.append(row)
    sol=m.solve(pd.DataFrame(rows),angles,True,False,(-600,600,-600,600))
    assert 'pathloss_exponent' not in sol
    assert 'reference_power' not in sol
