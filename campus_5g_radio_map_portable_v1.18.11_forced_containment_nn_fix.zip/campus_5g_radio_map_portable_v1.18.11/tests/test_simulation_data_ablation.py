from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RECON_ROOT = ROOT / "workflows" / "reconstruction"
LOCALIZATION_SCRIPT = ROOT / "workflows" / "localization" / "run_27stations_multicandidate_cv_localization.py"

if str(RECON_ROOT) not in sys.path:
    sys.path.insert(0, str(RECON_ROOT))


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.path.insert(0, str(path.parent))
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


class _PlanarPrior:
    @staticmethod
    def sample(xy: np.ndarray) -> np.ndarray:
        xy = np.asarray(xy, dtype=float)
        return -95.0 + 0.25 * xy[:, 0] - 0.10 * xy[:, 1]


def test_simulation_residual_nn_uses_same_training_points_and_corrects_prior():
    reconstruction = _load(RECON_ROOT / "run_reconstruction.py", "simulation_ablation_reconstruction_test")
    train_xy = np.asarray([[0.0, 0.0], [10.0, 0.0], [0.0, 10.0], [10.0, 10.0]])
    train_y = _PlanarPrior.sample(train_xy) + 6.0
    query_xy = np.asarray([[2.0, 3.0], [8.0, 7.0]])
    baseline = np.full(len(query_xy), -100.0)

    prediction, diagnostics = reconstruction.simulation_residual_nearest_neighbor(
        prior=_PlanarPrior(),
        train_xy=train_xy,
        train_y=train_y,
        query_xy=query_xy,
        baseline_prediction=baseline,
    )

    assert np.allclose(prediction, _PlanarPrior.sample(query_xy) + 6.0, atol=1e-6)
    assert diagnostics["simulation_prior_training_count"] == len(train_xy)
    assert diagnostics["simulation_fallback_fraction"] == 0.0


def test_reconstruction_paired_composite_uses_matched_percentages(tmp_path: Path):
    reconstruction = _load(RECON_ROOT / "run_reconstruction.py", "simulation_ablation_composite_test")
    x_axis = np.arange(8, dtype=float)
    y_axis = np.arange(8, dtype=float)
    baseline = np.full((8, 8), -90.0)
    assisted = np.full((8, 8), -82.0)
    output = tmp_path / "paired.png"

    reconstruction.plot_paired_reconstruction_composite(
        output,
        representative_maps={
            1: (baseline, assisted, 17.0, 14.0),
            5: (baseline + 1.0, assisted + 1.0, 15.0, 12.0),
            10: (baseline + 2.0, assisted + 2.0, 14.0, 11.0),
        },
        x_axis=x_axis,
        y_axis=y_axis,
        building_mask=np.zeros((8, 8), dtype=bool),
        min_dbm=-120.0,
        max_dbm=-40.0,
        dpi=72,
    )

    assert output.is_file()
    assert output.stat().st_size > 0


def test_localization_samples_simulation_at_the_same_measured_locations(tmp_path: Path):
    localization = _load(LOCALIZATION_SCRIPT, "simulation_ablation_localization_test")
    x = np.linspace(-40.0, 40.0, 17)
    y = np.linspace(-30.0, 30.0, 13)
    xx, yy = np.meshgrid(x, y)
    station_rows = []
    for sector, pci in enumerate((558, 559, 560), start=1):
        center_x = 10.0 * np.cos(2.0 * np.pi * (sector - 1) / 3.0)
        center_y = 10.0 * np.sin(2.0 * np.pi * (sector - 1) / 3.0)
        rsrp = -55.0 - 0.025 * ((xx - center_x) ** 2 + (yy - center_y) ** 2)
        path = tmp_path / f"station_03_pci_{pci}_pure_simulation.npz"
        np.savez_compressed(
            path,
            station_id=np.asarray([3]),
            pci=np.asarray([pci]),
            x_m=x,
            y_m=y,
            rsrp_dbm=rsrp,
            building_mask=np.zeros(rsrp.shape, dtype=bool),
        )
        station_rows.append({"station_id": 3, "sector_index": sector, "pci": pci})

    selected = pd.DataFrame({
        "point_id": [0, 1, 2, 3],
        "x_m": [-20.0, 0.0, 20.0, 10.0],
        "y_m": [-10.0, 0.0, 10.0, -20.0],
        "rsrp_s1": [-83.0, -70.0, -76.0, -79.0],
        "rsrp_s2": [-80.0, -73.0, -81.0, -77.0],
        "rsrp_s3": [-85.0, -78.0, -72.0, -82.0],
        "observed_sector_count": [3, 3, 3, 3],
    })
    simulation_selected, selected_with_simulation, diagnostics = (
        localization.build_collocated_simulation_dataset(
            project_root=ROOT,
            simulation_root=tmp_path,
            station=pd.DataFrame(station_rows),
            selected=selected,
            station_id=3,
            omni=False,
            strict=True,
        )
    )

    assert diagnostics["simulation_prior_count"] == 3
    assert diagnostics["simulation_matched_location_count"] == len(selected)
    assert diagnostics["simulation_matched_observation_count"] == 3 * len(selected)
    assert diagnostics["simulation_map_geometry_used_for_candidate_location"] is False
    assert np.allclose(simulation_selected[["x_m", "y_m"]], selected[["x_m", "y_m"]])
    assert np.isfinite(simulation_selected[["rsrp_s1", "rsrp_s2", "rsrp_s3"]].to_numpy()).all()
    assert np.allclose(
        selected_with_simulation[["simulated_rsrp_s1", "simulated_rsrp_s2", "simulated_rsrp_s3"]],
        simulation_selected[["rsrp_s1", "rsrp_s2", "rsrp_s3"]].to_numpy(),
    )


def test_localization_rejects_simulation_channel_without_two_valid_lolo_folds():
    localization = _load(LOCALIZATION_SCRIPT, "simulation_lolo_support_test")
    selected = pd.DataFrame({
        "x_m": [0.0, 10.0, 20.0],
        "y_m": [0.0, 0.0, 0.0],
        "rsrp_s1": [-70.0, -72.0, -74.0],
        "rsrp_s2": [-71.0, -73.0, np.nan],
        "rsrp_s3": [-69.0, -75.0, np.nan],
    })

    diagnostics = localization.lolo_support_diagnostics(
        selected, direction_used=True, omni=False,
    )

    assert diagnostics["simulation_lolo_distinct_location_count"] == 3
    assert diagnostics["simulation_lolo_valid_fold_count"] == 1
    assert diagnostics["simulation_lolo_usable"] is False


def test_localization_ablation_summary_reports_signed_error_delta():
    localization = _load(LOCALIZATION_SCRIPT, "simulation_ablation_summary_test")
    without = pd.DataFrame({
        "station_id": [2, 3],
        "horizontal_error_m": [100.0, 50.0],
        "cv_rmse_db": [8.0, 7.0],
        "predicted_x_m": [0.0, 10.0],
        "predicted_y_m": [0.0, 10.0],
    })
    with_simulation = pd.DataFrame({
        "station_id": [2, 3],
        "horizontal_error_m": [80.0, 55.0],
        "cv_rmse_db": [7.5, 6.8],
        "predicted_x_m": [5.0, 12.0],
        "predicted_y_m": [0.0, 10.0],
    })

    paired, summary = localization.summarize_simulation_ablation(without, with_simulation)

    assert paired["error_delta_with_minus_without_m"].tolist() == [-20.0, 5.0]
    assert paired["simulation_improved_localization"].tolist() == [True, False]
    assert summary["improved_station_count"].iloc[0] == 1
