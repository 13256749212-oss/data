from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW_SCRIPT = ROOT / "workflows" / "visualization" / "plot_raw_measurement_dataset.py"
STRUCT_SCRIPT = ROOT / "workflows" / "visualization" / "plot_dataset_output_structure.py"


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


raw = _load("dataset_raw_vis", RAW_SCRIPT)
structure = _load("dataset_structure_vis", STRUCT_SCRIPT)


def test_raw_reader_skips_metadata_and_preserves_extra_field(tmp_path: Path):
    p = tmp_path / "sample.csv"
    p.write_text(
        '"TIME","LATITUDE","LONGITUDE","NR5G SS RSRP"\n'
        '0,0,0,0,FA4919EA,EC624327,E97D2DB1,9581D094,84B5E45B,73EA1822,B7198906,421ADD10,63B29582,52E6A949,A6E20666,A64DBCCD,747E61BB,B9FEBE7C,6603415F,314EF0D7,96163A2D,F5A6C7A9,49A224C7,8013B21A,45945C1F,34C86FE6,9866E60A,CACA8AB5,854A4DF4,DB9676EE,4ED8C0A1,3E0CF468\n'
        '20260725 10:28:30.138,24.831435,102.858915,-68.7,EXTRA\n',
        encoding="utf-8-sig",
    )
    df = raw.read_cellular_pro_csv(p)
    assert len(df) == 1
    assert str(df.loc[0, "TIME"]).startswith("20260725 10:28:30")
    assert abs(float(df.loc[0, "LATITUDE"]) - 24.831435) < 1e-9
    assert abs(float(df.loc[0, "NR5G SS RSRP"]) + 68.7) < 1e-9
    assert "_EXTRA_01" in df.columns


def test_publication_defaults_are_1000_dpi_and_7480_px_wide():
    assert raw.DPI == 1000
    assert structure.DPI == 1000
    assert round(raw.FIG_WIDTH_IN * raw.DPI) == 7480
    assert round(structure.FIG_WIDTH_IN * structure.DPI) == 7480


def test_local_xy_center_maps_to_zero():
    x, y = raw._local_xy(np.asarray([24.83]), np.asarray([102.85]), 24.83, 102.85)
    assert abs(float(x[0])) < 1e-8
    assert abs(float(y[0])) < 1e-8
