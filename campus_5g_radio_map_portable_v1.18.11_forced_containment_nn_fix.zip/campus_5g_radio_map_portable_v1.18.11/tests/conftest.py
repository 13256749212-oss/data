from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
RADIO_MAP_ROOT = ROOT / "workflows" / "radio_map"
for path in (ROOT, RADIO_MAP_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))
