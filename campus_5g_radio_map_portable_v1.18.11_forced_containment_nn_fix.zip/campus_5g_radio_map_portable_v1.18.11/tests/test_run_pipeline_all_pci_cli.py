from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "run_pipeline.py"
SPEC = importlib.util.spec_from_file_location("run_pipeline_cli", MODULE_PATH)
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = MOD
SPEC.loader.exec_module(MOD)


def test_localize_all_pci_cli_accepts_all_station_token():
    parser = MOD.build_parser()
    args = parser.parse_args(["localize-all-pci", "--station-id", "all"])
    assert args.station_id == "all"


def test_localize_all_pci_cli_accepts_station22_token():
    parser = MOD.build_parser()
    args = parser.parse_args(["localize-all-pci", "--station-id", "22"])
    assert args.station_id == "22"
