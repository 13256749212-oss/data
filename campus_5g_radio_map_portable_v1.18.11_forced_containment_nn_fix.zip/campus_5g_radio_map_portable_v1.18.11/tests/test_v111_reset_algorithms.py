from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def _load(path,name):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str(path.parent)); sys.modules[name]=m
    try: spec.loader.exec_module(m)
    finally: sys.path.pop(0)
    return m

def test_basic_random_reconstruction_ranking_is_seeded_and_nested():
    m=_load(ROOT/'workflows/reconstruction/run_reconstruction.py','r111')
    df=pd.DataFrame({'x_m':np.arange(100.),'y_m':np.arange(100.),'measured_rsrp_dbm':-80.})
    a=m.basic_random_nested_ranking(df,20,seed=12); b=m.basic_random_nested_ranking(df,20,seed=12)
    assert a[['x_m','y_m']].equals(b[['x_m','y_m']])
    assert (a['selection_method']=='basic_random_nested_fixed_seed').all()
    assert a['random_rank'].tolist()==list(range(1,21))

def test_rsgl_random_point_selection_is_uniform_seeded():
    m=_load(ROOT/'workflows/localization/run_27stations_rank_sector_localization.py','l111')
    n=30; df=pd.DataFrame({'x_m':np.arange(n,dtype=float),'y_m':np.arange(n,dtype=float),'z_m':1.5,
        'rsrp_s1':np.where(np.arange(n)%2==0,-80.,np.nan),'rsrp_s2':np.where(np.arange(n)%3==0,-82.,np.nan),'rsrp_s3':np.where(np.arange(n)%5==0,-84.,np.nan)})
    a=m.random_points(df,10,123,False); b=m.random_points(df,10,123,False)
    assert a[['x_m','y_m']].equals(b[['x_m','y_m']])
    assert len(a)==10 and a[['rsrp_s1','rsrp_s2','rsrp_s3']].notna().any(axis=1).all()

def test_rsgl_solver_returns_finite_xy_on_synthetic_sector_data():
    m=_load(ROOT/'workflows/localization/run_27stations_rank_sector_localization.py','l111solver')
    tx=np.array([0.,0.]); angles=np.array([0.,2*np.pi/3,-2*np.pi/3])
    pts=[]
    rng=np.random.default_rng(2)
    for i,ang in enumerate(np.linspace(0,2*np.pi,15,endpoint=False)):
        p=np.array([120*np.cos(ang),120*np.sin(ang)]); bearing=np.arctan2(p[1],p[0]); row={'x_m':p[0],'y_m':p[1],'z_m':1.5,'selection_rank':i+1}
        for j,a in enumerate(angles,1):
            gain=m.sector_gain_db(np.array([bearing-a]))[0]; row[f'rsrp_s{j}']=-25-28*np.log10(np.sqrt(np.sum(p*p)+28.5**2))+gain+rng.normal(0,1); row[f'pci_s{j}']=500+j
        pts.append(row)
    df=pd.DataFrame(pts)
    sol=m.solve(df,angles,False,(-500,500,-500,500))
    assert np.isfinite(sol['final_xy']).all()
    assert np.linalg.norm(sol['final_xy']-tx)<120
