from __future__ import annotations

import importlib.util
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"


def _load():
    spec = importlib.util.spec_from_file_location("recon_v1180", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


class PlanePrior:
    def sample(self, xy):
        xy = np.asarray(xy, dtype=float)
        return -90.0 + 0.3 * xy[:, 0] - 0.1 * xy[:, 1]


def test_fixed_sionna_residual_nn_is_exact_nn_residual_without_affine():
    r = _load()
    train_xy = np.asarray([[0., 0.], [10., 0.], [0., 10.]])
    prior = PlanePrior()
    train_y = prior.sample(train_xy) + np.asarray([2.0, 4.0, 6.0])
    q = np.asarray([[1., 1.], [9., 1.], [1., 9.]])
    baseline = np.asarray([-80., -80., -80.])
    pred, diag = r.fixed_sionna_residual_nearest_neighbor(
        prior=prior, train_xy=train_xy, train_y=train_y, query_xy=q, baseline_prediction=baseline
    )
    expected = prior.sample(q) + np.asarray([2.0, 4.0, 6.0])
    assert np.allclose(pred, expected)
    assert diag["simulation_prior_training_count"] == 3


def test_primary_rmse_mask_includes_selected_cells_when_valid():
    r = _load()
    ref = np.asarray([[-80., -90.], [-100., np.nan]])
    pred = np.asarray([[-81., -88.], [-103., np.nan]])
    building = np.asarray([[False, False], [False, True]])
    mask = (~building) & np.isfinite(ref)
    # All three valid outdoor cells are included. There is no selected-cell removal.
    assert int(mask.sum()) == 3
    expected = np.sqrt((1.0 + 4.0 + 9.0) / 3.0)
    assert np.isclose(r.rmse(ref, pred, mask), expected)


def test_nested_random_ranking_is_reproducible_and_prefix_based():
    r = _load()
    df = pd.DataFrame({
        "x_m": np.arange(20, dtype=float),
        "y_m": np.zeros(20),
        "measured_rsrp_dbm": np.linspace(-100, -70, 20),
    })
    a = r.basic_random_nested_ranking(df, max_count=10, seed=123)
    b = r.basic_random_nested_ranking(df, max_count=10, seed=123)
    assert a[["x_m","y_m"]].equals(b[["x_m","y_m"]])
    assert len(a.iloc[:5]) == 5
    assert set(a.iloc[:5]["x_m"]).issubset(set(a.iloc[:10]["x_m"]))


def test_trial_aggregation_uses_full_grid_metrics_not_heldout_measurements():
    r = _load()
    rows = []
    for trial in range(2):
        for variant, sim, value in [("without_simulation", False, 10.0 + trial), ("with_simulation", True, 9.0 + trial)]:
            rows.append({
                "trial_id": trial,
                "sampling_percent": 10,
                "selected_measured_point_count": 10,
                "total_eligible_measured_points": 100,
                "reference_valid_outdoor_cell_count": 200000,
                "variant": variant,
                "simulation_data_used": sim,
                "rmse_db": value,
                "mae_db": value-1,
                "bias_pred_minus_reference_db": 0.0,
                "rmse_unsampled_db": value+0.1,
                "mae_unsampled_db": value-0.9,
            })
    paired, long = r._aggregate_trials(pd.DataFrame(rows))
    assert int(paired.iloc[0]["reference_valid_outdoor_cell_count"]) == 200000
    assert np.isclose(paired.iloc[0]["rmse_db_without_simulation"], 10.5)
    assert np.isclose(paired.iloc[0]["rmse_db_with_simulation"], 9.5)
    assert "evaluation_measured_point_count" not in paired.columns


def test_formal_path_uses_ckdtree_nn_and_full_reference_mask():
    text = MOD.read_text(encoding="utf-8")
    formal = text[text.index("def main() -> int:"):]
    assert "cKDTree(train_xy)" in formal
    assert "reference_eval_mask" in formal
    assert "all_finite_outdoor_cells_of_512x512_measurement_filled_map" in formal
    assert "heldout" not in formal.lower() or "no_heldout_measurement_evaluation" in formal
    assert "ordinary_kriging" not in formal
    assert "robust_idw" not in formal
