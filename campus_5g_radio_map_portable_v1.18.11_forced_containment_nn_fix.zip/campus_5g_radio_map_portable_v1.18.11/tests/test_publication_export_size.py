from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
EVAL = ROOT / "workflows" / "evaluation" / "compare_joint_map_with_measurements.py"
spec = importlib.util.spec_from_file_location("joint_eval_size", EVAL)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def _make_simple_figure():
    fig = plt.figure(figsize=mod._publication_figsize_inches(), dpi=100)
    ax = fig.add_axes([0.12, 0.14, 0.80, 0.78])
    ax.plot([0, 1], [0, 1])
    return fig


def test_map_png_is_full_page_7480_px_at_1000_dpi(tmp_path: Path):
    fig = _make_simple_figure()
    target = tmp_path / "map_figure.png"
    try:
        mod._save_png(fig, target, dpi=mod.MAP_DPI)
    finally:
        plt.close(fig)
    assert target.is_file()
    with Image.open(target) as im:
        width, height = im.size
        assert width >= 7480
        assert width >= 3543
        assert height > 0
        assert width == 7480


def test_comparison_png_is_at_least_full_page_7480_px_at_1000_dpi(tmp_path: Path):
    fig = _make_simple_figure()
    target = tmp_path / "comparison_figure.png"
    try:
        mod._save_png(fig, target, dpi=mod.COMPARISON_DPI)
    finally:
        plt.close(fig)
    assert target.is_file()
    with Image.open(target) as im:
        width, height = im.size
        assert width >= 7480
        assert width >= 3543
        assert height > 0
        assert width == 7480
