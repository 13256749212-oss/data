from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "workflows" / "localization" / "run_27stations_multicandidate_cv_localization.py"


def _load():
    spec = importlib.util.spec_from_file_location("mcvl_v1182_test", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.path.insert(0, str(SCRIPT.parent))
    sys.modules["mcvl_v1182_test"] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


def test_nearest_floor_completion_keeps_same_receiver_locations_and_supports_lolo(monkeypatch, tmp_path):
    m = _load()

    class FakePrior:
        def sample_nearest(self, xy):
            # Reproduce the failure pattern: only 2 direct values per PCI would
            # otherwise leave 6 matched observations across three sectors.
            out = np.full(len(xy), np.nan, dtype=float)
            out[:2] = [-85.0, -90.0]
            return out

        def sample(self, xy):
            return self.sample_nearest(xy)

    fake_npz = tmp_path / "station_13_pci_1_pure_simulation.npz"
    fake_npz.write_bytes(b"x")
    monkeypatch.setattr(m, "discover_simulation_prior", lambda *a, **k: fake_npz)
    monkeypatch.setattr(m, "load_simulation_prior", lambda *a, **k: FakePrior())

    selected = pd.DataFrame({
        "x_m": np.arange(10, dtype=float),
        "y_m": np.arange(10, dtype=float),
        "rsrp_s1": np.linspace(-80, -89, 10),
        "rsrp_s2": np.linspace(-82, -91, 10),
        "rsrp_s3": np.linspace(-84, -93, 10),
    })
    station = pd.DataFrame({
        "sector_index": [1, 2, 3],
        "pci": [101, 102, 103],
    })

    sim, _, diag = m.build_collocated_simulation_dataset(
        project_root=tmp_path,
        simulation_root=tmp_path,
        station=station,
        selected=selected,
        station_id=13,
        omni=False,
        strict=True,
        simulation_sampling="nearest",
        fill_missing_with_floor=True,
        simulation_floor_dbm=-120.0,
    )

    # All 10 original receiver locations remain; no measurement point is dropped.
    assert len(sim) == 10
    assert np.isfinite(sim[["rsrp_s1", "rsrp_s2", "rsrp_s3"]].to_numpy(float)).all()
    assert diag["simulation_direct_valid_observation_count"] == 6
    assert diag["simulation_floor_filled_observation_count"] == 24
    assert diag["simulation_matched_observation_count"] == 30
    support = m.lolo_support_diagnostics(sim, direction_used=False, omni=False)
    assert support["simulation_lolo_usable"] is True
    assert support["simulation_lolo_valid_fold_count"] == 10
