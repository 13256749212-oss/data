from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LOC_ROOT = ROOT / "workflows" / "localization"
if str(LOC_ROOT) not in sys.path:
    sys.path.insert(0, str(LOC_ROOT))

MODULE_PATH = LOC_ROOT / "all_pci_cluster_localization.py"
SPEC = importlib.util.spec_from_file_location("all_pci_cluster_localization", MODULE_PATH)
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = MOD
SPEC.loader.exec_module(MOD)


def _make_line_points(pci: int, sector: int, center, direction, seed: int):
    rng = np.random.default_rng(seed)
    t = np.linspace(-120.0, 120.0, 80)
    direction = np.asarray(direction, float)
    normal = np.asarray([-direction[1], direction[0]], float)
    xy = np.asarray(center, float) + t[:, None] * direction + rng.normal(0.0, 3.0, size=(len(t), 1)) * normal
    rsrp = -65.0 - 0.08 * (t - t.min()) + rng.normal(0.0, 1.0, len(t))
    return pd.DataFrame({
        "pci": pci,
        "sector_index": sector,
        "x_m": xy[:, 0],
        "y_m": xy[:, 1],
        "rsrp_dbm": rsrp,
        "raw_count": np.ones(len(t), dtype=int),
    })


def test_three_weighted_sector_axes_intersect_near_common_origin():
    origin = np.asarray([25.0, -40.0])
    parts = [
        _make_line_points(101, 1, origin, [1.0, 0.0], 1),
        _make_line_points(102, 2, origin, [-0.5, 0.8660254], 2),
        _make_line_points(103, 3, origin, [-0.5, -0.8660254], 3),
    ]
    fits = []
    for part in parts:
        centers, _ = MOD._cluster_pci_points(part, eps_m=20.0, min_samples=3)
        fits.append(MOD._fit_sector(part, centers))
    estimate, residual = MOD._intersect_lines(fits)
    assert np.linalg.norm(estimate - origin) < 8.0
    assert residual < 8.0


def test_cluster_center_output_has_expected_columns():
    part = _make_line_points(699, 1, [0.0, 0.0], [1.0, 0.0], 4)
    centers, labels = MOD._cluster_pci_points(part, eps_m=20.0, min_samples=3)
    assert len(labels) == len(part)
    assert not centers.empty
    expected = {
        "pci", "sector_index", "cluster_id", "cluster_point_count",
        "cluster_center_x_m", "cluster_center_y_m", "cluster_rsrp_max_dbm",
    }
    assert expected.issubset(centers.columns)


def test_single_pci_fit_provides_finite_strongest_cluster_center():
    part = _make_line_points(800, 1, [30.0, 15.0], [1.0, 0.2], 5)
    centers, labels = MOD._cluster_pci_points(part, eps_m=20.0, min_samples=3)
    assigned = part.copy()
    assigned["cluster_id"] = labels
    fit = MOD._fit_sector(assigned, centers)
    assert fit.pci == 800
    assert np.all(np.isfinite(fit.strongest_cluster_xy))
    assert np.isfinite(fit.strongest_cluster_rsrp_dbm)
