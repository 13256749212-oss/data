from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"
RECON_DIR = ROOT / "workflows" / "reconstruction"
if str(RECON_DIR) not in sys.path:
    sys.path.insert(0, str(RECON_DIR))


def _load():
    spec = importlib.util.spec_from_file_location("recon_v1187", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _frame(nx: int = 24, ny: int = 16) -> pd.DataFrame:
    gx, gy = np.meshgrid(np.arange(nx, dtype=float), np.arange(ny, dtype=float))
    # Keep only a road-like subset, not every grid cell.
    keep = ((gy.astype(int) % 3) == 0) | ((gx.astype(int) % 5) == 0)
    x = gx[keep].ravel()
    y = gy[keep].ravel()
    return pd.DataFrame({
        "x_m": x,
        "y_m": y,
        "measured_rsrp_dbm": -82.0 + 0.6 * x - 0.4 * y,
        "ix": x.astype(int),
        "iy": y.astype(int),
    })


def test_hierarchical_selector_is_strict_nested_and_exact_counts():
    r = _load()
    frame = _frame()
    x_axis = np.arange(24, dtype=float)
    y_axis = np.arange(16, dtype=float)
    mask = np.ones((16, 24), dtype=bool)
    n = len(frame)
    counts = [max(1, int(np.ceil(n * p / 100.0))) for p in [1, 2, 5, 10]]
    ranked, audit = r.hierarchical_nested_spatial_ranking(
        frame, x_axis, y_axis, mask, min_count=counts[0], max_count=counts[-1]
    )
    assert len(ranked) == counts[-1]
    for a, b in zip(counts[:-1], counts[1:]):
        sa = set(map(tuple, ranked.iloc[:a][["x_m", "y_m"]].to_numpy()))
        sb = set(map(tuple, ranked.iloc[:b][["x_m", "y_m"]].to_numpy()))
        assert sa.issubset(sb)
    assert audit["sampling_sets_nested"].all()


def test_hierarchical_selector_does_not_use_any_rsrp_amplitude():
    r = _load()
    a = _frame()
    b = a.copy()
    b["measured_rsrp_dbm"] = np.linspace(-119.0, -41.0, len(b))[::-1]
    x_axis = np.arange(24, dtype=float)
    y_axis = np.arange(16, dtype=float)
    mask = np.ones((16, 24), dtype=bool)
    min_count = max(1, int(np.ceil(len(a) * 0.01)))
    max_count = max(1, int(np.ceil(len(a) * 0.10)))
    ra, aa = r.hierarchical_nested_spatial_ranking(a, x_axis, y_axis, mask, min_count, max_count)
    rb, ab = r.hierarchical_nested_spatial_ranking(b, x_axis, y_axis, mask, min_count, max_count)
    pd.testing.assert_frame_equal(ra[["x_m", "y_m"]], rb[["x_m", "y_m"]])
    assert not aa["selection_uses_reference_rsrp"].any()
    assert not aa["selection_uses_measured_rsrp"].any()
    assert not aa["selection_uses_simulation_rsrp"].any()


def test_hierarchical_geometry_improves_from_low_to_high_density():
    r = _load()
    frame = _frame()
    x_axis = np.arange(24, dtype=float)
    y_axis = np.arange(16, dtype=float)
    mask = np.ones((16, 24), dtype=bool)
    min_count = max(1, int(np.ceil(len(frame) * 0.01)))
    max_count = max(1, int(np.ceil(len(frame) * 0.10)))
    _, audit = r.hierarchical_nested_spatial_ranking(frame, x_axis, y_axis, mask, min_count, max_count)
    audit = audit.sort_values("selected_measured_point_count")
    vals = audit["domain_mean_squared_nearest_distance_m2"].to_numpy(float)
    # Adding points in the reverse elimination hierarchy cannot increase nearest-distance loss.
    assert np.all(np.diff(vals) <= 1e-10)
    assert vals[-1] < vals[0]


def test_quantitative_clipping_removed_from_formal_main():
    text = MOD.read_text(encoding="utf-8")
    formal = text[text.index("def main() -> int:"):]
    assert "reference_map[finite_reference] = np.clip" not in formal
    assert "m_prediction = np.clip" not in formal
    assert "ms_prediction = np.clip" not in formal
    assert '"quantitative_rsrp_clipping_applied": False' in formal
