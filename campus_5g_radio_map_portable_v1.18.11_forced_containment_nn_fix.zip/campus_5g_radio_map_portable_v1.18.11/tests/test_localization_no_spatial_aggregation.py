from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LOC_ROOT = ROOT / "workflows" / "localization"
if str(LOC_ROOT) not in sys.path:
    sys.path.insert(0, str(LOC_ROOT))

import legacy_pgrmsbil as common


def test_point_table_uses_rx_point_id_without_spatial_rounding():
    frame = pd.DataFrame({
        "rx_point_id": ["a", "a", "b", "b"],
        "x_m": [0.10, 0.10, 0.20, 0.20],
        "y_m": [0.10, 0.10, 0.20, 0.20],
        "z_m": [1.5, 1.5, 1.5, 1.5],
        "sector_index": [1, 2, 1, 2],
        "pci": [101, 102, 101, 102],
        "rsrp_dbm": [-80.0, -85.0, -82.0, -87.0],
    })
    # These two receiver samples are only ~0.14 m apart. A 2.77 m grid would
    # merge them, but the no-aggregation workflow must preserve both.
    out = common.point_table(frame)
    assert len(out) == 2
    assert set(out["receiver_point_key"]) == {"a", "b"}


def test_pipeline_localization_commands_do_not_expose_aggregation_option():
    module_path = ROOT / "run_pipeline.py"
    spec = importlib.util.spec_from_file_location("run_pipeline_noagg", module_path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    parser = mod.build_parser()
    localize = parser.parse_args(["localize"])
    all_pci = parser.parse_args(["localize-all-pci", "--station-id", "all"])
    assert not hasattr(localize, "aggregation_m")
    assert not hasattr(all_pci, "aggregation_m")
