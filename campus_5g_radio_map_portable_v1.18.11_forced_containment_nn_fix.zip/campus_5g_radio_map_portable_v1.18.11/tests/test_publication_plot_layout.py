from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
RECON_ROOT = ROOT / "workflows" / "reconstruction"
if str(RECON_ROOT) not in sys.path:
    sys.path.insert(0, str(RECON_ROOT))

from radio_reconstruction.plotting import (
    _create_fixed_square_map_axes,
    _lock_extent_512,
)

_eval_path = ROOT / "workflows" / "evaluation" / "compare_joint_map_with_measurements.py"
_spec = importlib.util.spec_from_file_location("joint_eval", _eval_path)
_joint_eval = importlib.util.module_from_spec(_spec)
assert _spec and _spec.loader
sys.modules[_spec.name] = _joint_eval
_spec.loader.exec_module(_joint_eval)


def _assert_aligned_in_figure_coordinates(ax, cax, tolerance: float = 1e-9):
    apos = ax.get_position(original=False)
    cpos = cax.get_position(original=False)
    assert abs(apos.y0 - cpos.y0) <= tolerance
    assert abs(apos.y1 - cpos.y1) <= tolerance
    assert abs(apos.height - cpos.height) <= tolerance


def test_joint_map_axes_and_colorbar_have_identical_figure_heights():
    fig = plt.figure(figsize=(12, 9), dpi=180)
    ax, cax = _joint_eval._create_fixed_map_axes(
        fig, xlim=(-1732.5, 2267.5), ylim=(-1430.47, 1569.53)
    )
    try:
        _assert_aligned_in_figure_coordinates(ax, cax)
    finally:
        plt.close(fig)


def test_reconstruction_axes_and_colorbar_have_identical_figure_heights():
    fig = plt.figure(figsize=(8.2, 7.4), dpi=180)
    ax, cax = _create_fixed_square_map_axes(fig, extent=[-256.0, 256.0, -256.0, 256.0])
    try:
        _assert_aligned_in_figure_coordinates(ax, cax)
    finally:
        plt.close(fig)


def test_reconstruction_extent_is_strictly_512_m_square():
    fig = plt.figure()
    ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
    try:
        _lock_extent_512(ax, [-256.0, 256.0, -256.0, 256.0])
        assert tuple(ax.get_xlim()) == (-256.0, 256.0)
        assert tuple(ax.get_ylim()) == (-256.0, 256.0)
        with pytest.raises(ValueError):
            _lock_extent_512(ax, [-300.0, 300.0, -256.0, 256.0])
    finally:
        plt.close(fig)


def test_localization_axes_and_colorbar_have_identical_figure_heights():
    loc_root = ROOT / "workflows" / "localization"
    if str(loc_root) not in sys.path:
        sys.path.insert(0, str(loc_root))
    loc_path = loc_root / "run_27stations_sparse_localization_v2.py"
    spec = importlib.util.spec_from_file_location("loc_eval", loc_path)
    loc_mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = loc_mod
    spec.loader.exec_module(loc_mod)
    fig = plt.figure(figsize=(8.6, 7.2), dpi=180)
    ax, cax = loc_mod._create_fixed_equal_axes(fig, xlim=(-200.0, 200.0), ylim=(-240.0, 240.0))
    try:
        _assert_aligned_in_figure_coordinates(ax, cax)
    finally:
        plt.close(fig)


def test_joint_4000x3000_axes_and_colorbar_have_identical_figure_heights():
    joint_path = ROOT / "workflows" / "radio_map" / "generate_joint_best_server_4000x3000.py"
    spec = importlib.util.spec_from_file_location("joint_map_gen", joint_path)
    joint_mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = joint_mod
    spec.loader.exec_module(joint_mod)
    fig = plt.figure(figsize=(13, 9), dpi=180)
    ax, cax = joint_mod._create_fixed_map_axes(fig, [-1732.5, 2267.5, -1430.47, 1569.53])
    try:
        _assert_aligned_in_figure_coordinates(ax, cax)
    finally:
        plt.close(fig)
