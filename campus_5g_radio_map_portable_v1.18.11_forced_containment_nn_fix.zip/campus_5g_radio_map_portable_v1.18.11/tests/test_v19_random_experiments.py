from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent))
    sys.modules[name] = module
    try:
        assert spec.loader is not None
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


def test_random_localization_selection_is_seeded_and_uniform_candidate_based():
    m = _load(ROOT / "workflows/localization/run_27stations_sparse_localization_v2.py", "loc_v19")
    rng = np.random.default_rng(7)
    n = 40
    points = pd.DataFrame({
        "x_m": rng.normal(size=n),
        "y_m": rng.normal(size=n),
        "rsrp_s1": rng.normal(-80, 4, n),
        "rsrp_s2": rng.normal(-82, 4, n),
        "rsrp_s3": rng.normal(-84, 4, n),
    })
    a, _ = m.select_random_localization_points(points, 10, 1234, False)
    b, _ = m.select_random_localization_points(points, 10, 1234, False)
    c, _ = m.select_random_localization_points(points, 10, 1235, False)
    assert a[["x_m", "y_m"]].equals(b[["x_m", "y_m"]])
    assert not a[["x_m", "y_m"]].equals(c[["x_m", "y_m"]])
    assert len(a) == 10
    assert (a["selection_mode"] == "random").all()


def test_random10_summary_reports_mean_and_std():
    m = _load(ROOT / "workflows/localization/run_27stations_localization_multicount.py", "loc_mc_v19")
    rows = []
    for trial in range(1, 11):
        rows.append({
            "point_count": 10,
            "trial_index": trial,
            "trial_seed": 100 + trial,
            "station_count": 27,
            "mean_error_m": float(trial),
            "median_error_m": float(trial + 1),
            "rmse_m": float(trial + 2),
            "p90_error_m": float(trial + 3),
            "p95_error_m": float(trial + 4),
            "max_error_m": float(trial + 5),
            "within_50m_percent": 50.0,
            "within_100m_percent": 90.0,
        })
    summary = m.summarize_trials(pd.DataFrame(rows))
    assert int(summary.loc[0, "completed_trials"]) == 10
    assert np.isclose(float(summary.loc[0, "rmse_m_mean_over_trials"]), 7.5)
    assert float(summary.loc[0, "rmse_m_std_over_trials"]) > 0


def test_reconstruction_percent_parser_is_one_to_ten_capable():
    m = _load(ROOT / "workflows/reconstruction/run_reconstruction.py", "recon_v19")
    assert m.parse_percentages("1,2,3,4,5,6,7,8,9,10") == list(range(1, 11))


def test_random_selection_allows_more_points_than_complete_three_pci_rows():
    m = _load(ROOT / "workflows/localization/run_27stations_sparse_localization_v2.py", "loc_v191_partial")
    rng = np.random.default_rng(91)
    n = 30
    frame = pd.DataFrame({
        "x_m": np.arange(n, dtype=float),
        "y_m": rng.normal(size=n),
        "rsrp_s1": rng.normal(-80, 3, n),
        "rsrp_s2": rng.normal(-82, 3, n),
        "rsrp_s3": rng.normal(-84, 3, n),
    })
    # Only nine rows have all three PCIs. The rest are still valid partial-PCI points.
    frame.loc[9:15, "rsrp_s3"] = np.nan
    frame.loc[16:22, "rsrp_s2"] = np.nan
    frame.loc[23:, "rsrp_s1"] = np.nan
    complete_count = int(frame[["rsrp_s1", "rsrp_s2", "rsrp_s3"]].notna().all(axis=1).sum())
    assert complete_count == 9
    selected, _ = m.select_random_localization_points(frame, 15, 2026, False)
    assert len(selected) == 15
    assert int(selected["complete_three_pci_candidate_count"].iloc[0]) == 9
    assert int((selected["observed_sector_count"] == 3).sum()) >= 2
    assert (selected[["rsrp_s1", "rsrp_s2", "rsrp_s3"]].notna().sum(axis=0) >= 2).all()


def test_directional_objective_partial_pci_pairwise_fallback_is_finite():
    m = _load(ROOT / "workflows/localization/run_27stations_sparse_localization_v2.py", "loc_v191_obj")
    xy = np.asarray([[0.0, 0.0], [20.0, 0.0], [0.0, 20.0], [20.0, 20.0]])
    rss = np.asarray([
        [-70.0, -78.0, np.nan],
        [-72.0, np.nan, -85.0],
        [np.nan, -75.0, -82.0],
        [-74.0, -79.0, np.nan],
    ])
    envelope = np.nanmax(rss, axis=1)
    params = np.asarray([10.0, 10.0, 0.8, 2.7, -22.0])
    value = m.directional_objective(
        params, xy, rss, envelope, np.asarray([10.0, 10.0]), 1,
        "fixed", 0.0, 20.0,
    )
    assert np.isfinite(value)
    assert value < 1e11
