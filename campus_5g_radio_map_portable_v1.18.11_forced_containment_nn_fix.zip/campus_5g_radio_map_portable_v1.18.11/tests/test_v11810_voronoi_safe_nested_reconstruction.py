from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"
RECON_DIR = ROOT / "workflows" / "reconstruction"
if str(RECON_DIR) not in sys.path:
    sys.path.insert(0, str(RECON_DIR))


def _load():
    spec = importlib.util.spec_from_file_location("recon_v11810", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _frame(nx: int = 32, ny: int = 20) -> pd.DataFrame:
    gx, gy = np.meshgrid(np.arange(nx, dtype=float), np.arange(ny, dtype=float))
    keep = ((gy.astype(int) % 3) == 0) | ((gx.astype(int) % 6) == 0)
    x = gx[keep].ravel()
    y = gy[keep].ravel()
    # Mostly smooth field with one already-observable transition region.
    rsrp = -82.0 + 0.45 * x - 0.35 * y + 3.0 * np.sin(x / 4.0)
    return pd.DataFrame({
        "x_m": x,
        "y_m": y,
        "measured_rsrp_dbm": rsrp,
        "ix": x.astype(int),
        "iy": y.astype(int),
    })


def test_default_cli_uses_voronoi_safe_mode():
    run_pipeline = (ROOT / "run_pipeline.py").read_text(encoding="utf-8")
    recon = MOD.read_text(encoding="utf-8")
    assert 'default="voronoi-safe-adaptive-nested"' in run_pipeline
    assert 'default="voronoi-safe-adaptive-nested"' in recon


def test_voronoi_safe_selector_is_strict_nested_at_requested_stage_counts():
    r = _load()
    frame = _frame()
    mask = np.ones((20, 32), dtype=bool)
    n = len(frame)
    counts = [max(1, int(np.ceil(n * p / 100.0))) for p in range(1, 11)]
    ranked, audit = r.voronoi_safe_adaptive_nested_ranking(
        frame,
        np.arange(32, dtype=float),
        np.arange(20, dtype=float),
        mask,
        stage_target_counts=counts,
    )
    assert len(ranked) == counts[-1]
    assert ranked["voronoi_safe_rank"].tolist() == list(range(1, counts[-1] + 1))
    assert audit["sampling_sets_nested"].all()
    for a, b in zip(counts[:-1], counts[1:]):
        sa = set(map(tuple, ranked.iloc[:a][["x_m", "y_m"]].to_numpy()))
        sb = set(map(tuple, ranked.iloc[:b][["x_m", "y_m"]].to_numpy()))
        assert sa.issubset(sb)


def test_voronoi_safe_selector_does_not_use_unselected_labels():
    r = _load()
    a = _frame()
    mask = np.ones((20, 32), dtype=bool)
    n = len(a)
    counts = [max(3, int(np.ceil(n * p / 100.0))) for p in (2, 4, 6, 8, 10)]
    ra, audit = r.voronoi_safe_adaptive_nested_ranking(
        a, np.arange(32, dtype=float), np.arange(20, dtype=float), mask,
        stage_target_counts=counts,
    )
    selected_coords = set(map(tuple, ra[["x_m", "y_m"]].to_numpy()))
    b = a.copy()
    never_selected = [
        i for i, row in b.iterrows()
        if (float(row.x_m), float(row.y_m)) not in selected_coords
    ]
    b.loc[never_selected, "measured_rsrp_dbm"] += 75.0
    rb, _ = r.voronoi_safe_adaptive_nested_ranking(
        b, np.arange(32, dtype=float), np.arange(20, dtype=float), mask,
        stage_target_counts=counts,
    )
    pd.testing.assert_frame_equal(
        ra[["x_m", "y_m"]].reset_index(drop=True),
        rb[["x_m", "y_m"]].reset_index(drop=True),
    )
    assert not audit["selection_uses_reference_rsrp"].any()
    assert not audit["selection_uses_unselected_measured_rsrp"].any()
    assert not audit["selection_uses_simulation_rsrp"].any()
    assert not audit["selection_uses_final_rmse"].any()


def test_full_domain_nearest_distance_never_worsens_for_nested_prefixes():
    r = _load()
    frame = _frame()
    mask = np.ones((20, 32), dtype=bool)
    n = len(frame)
    counts = [max(2, int(np.ceil(n * p / 100.0))) for p in (2, 4, 6, 8, 10)]
    _, audit = r.voronoi_safe_adaptive_nested_ranking(
        frame, np.arange(32, dtype=float), np.arange(20, dtype=float), mask,
        stage_target_counts=counts,
    )
    vals = audit["domain_mean_squared_nearest_distance_m2"].to_numpy(float)
    assert np.all(np.diff(vals) <= 1e-10)
    assert vals[-1] < vals[0]


def test_source_has_no_rmse_based_accept_reject_in_selector():
    src = MOD.read_text(encoding="utf-8")
    start = src.index("def voronoi_safe_adaptive_nested_ranking(")
    end = src.index("\ndef _domain_support_xy(", start)
    body = src[start:end]
    assert "reference_map" not in body
    assert "simulation_prior" not in body
    assert "rmse(" not in body.lower()
    assert "np.minimum(previous_rmse" not in body
