from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RECON_ROOT = ROOT / "workflows" / "reconstruction"
if str(RECON_ROOT) not in sys.path:
    sys.path.insert(0, str(RECON_ROOT))

from radio_reconstruction.data import select_spatial_training_points
from radio_reconstruction.methods import PhysicsGuidedResidualGPRFusion, PhysicsGuidedResidualSpatialKriging


def _load_localization_sweep():
    path = ROOT / "workflows" / "localization" / "run_27stations_localization_multicount.py"
    spec = importlib.util.spec_from_file_location("localization_multicount", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_reconstruction_maximin_selection_is_nested_and_rsrp_independent():
    rng = np.random.default_rng(123)
    frame = pd.DataFrame({
        "x_m": rng.uniform(-250, 250, 120),
        "y_m": rng.uniform(-250, 250, 120),
        "measured_rsrp_dbm": rng.uniform(-115, -55, 120),
        "ix": np.arange(120) % 20,
        "iy": np.arange(120) // 20,
    })
    train10, _ = select_spatial_training_points(frame, 10, 20260805)
    train20, _ = select_spatial_training_points(frame, 20, 20260805)
    assert np.allclose(train10[["x_m", "y_m"]], train20.iloc[:10][["x_m", "y_m"]])
    assert train10["selection_rank"].tolist() == list(range(1, 11))

    changed = frame.copy()
    changed["measured_rsrp_dbm"] = changed["measured_rsrp_dbm"].sample(frac=1.0, random_state=7).to_numpy()
    train10_changed, _ = select_spatial_training_points(changed, 10, 20260805)
    assert np.allclose(train10[["x_m", "y_m"]], train10_changed[["x_m", "y_m"]])


class _DummyPrior:
    source_path = Path("dummy_prior.npz")
    selected_key = "rsrp_dbm"
    metadata = {"finite_fraction": 1.0}

    @staticmethod
    def sample(xy):
        xy = np.asarray(xy, dtype=float)
        return -85.0 + 0.018 * xy[:, 0] - 0.012 * xy[:, 1]


def test_enhanced_physics_guided_residual_gpr_returns_finite_predictions():
    rng = np.random.default_rng(77)
    xy = rng.uniform(-150, 150, size=(14, 2))
    prior = _DummyPrior.sample(xy)
    residual = 4.0 * np.sin(xy[:, 0] / 80.0) + 2.0 * np.cos(xy[:, 1] / 70.0)
    values = prior + 3.0 + residual + rng.normal(0.0, 0.35, size=len(xy))

    model = PhysicsGuidedResidualGPRFusion(
        _DummyPrior(), random_seed=11, cv_folds=3, final_optimizer_restarts=0
    ).fit(xy, values)
    query = rng.uniform(-140, 140, size=(25, 2))
    pred, std = model.predict(query, return_std=True)
    assert pred.shape == (25,)
    assert std.shape == (25,)
    assert np.isfinite(pred).all()
    assert np.isfinite(std).all()
    assert 0.0 <= model.fusion_weight <= 1.0
    diagnostics = model.diagnostics
    assert diagnostics["algorithm_name"].startswith("Enhanced Physics-Guided")
    assert diagnostics["valid_prior_training_count"] == len(xy)



def test_pgrsk_spatial_block_cv_returns_finite_predictions_and_safe_mode():
    rng = np.random.default_rng(177)
    xy = rng.uniform(-180, 180, size=(18, 2))
    # Deliberately use a slope != 1 so affine calibration is exercised.
    prior = _DummyPrior.sample(xy)
    residual = 2.5 * np.sin(xy[:, 0] / 95.0) + 1.5 * np.cos(xy[:, 1] / 80.0)
    values = 0.78 * prior - 15.0 + residual + rng.normal(0.0, 0.4, size=len(xy))

    model = PhysicsGuidedResidualSpatialKriging(
        _DummyPrior(), random_seed=17, cv_blocks=4, final_optimizer_restarts=0
    ).fit(xy, values)
    query = rng.uniform(-170, 170, size=(31, 2))
    pred, std = model.predict(query, return_std=True)
    assert pred.shape == (31,)
    assert std.shape == (31,)
    assert np.isfinite(pred).all()
    assert np.isfinite(std).all()
    assert model.selected_mode in {"safety", "hybrid"}
    assert model.selected_safety_model_name in {"ordinary_kriging", "adaptive_matern_gpr"}
    assert 0.35 <= model.affine_a <= 1.65
    diagnostics = model.diagnostics
    assert diagnostics["algorithm_name"].startswith("Physics-Guided Residual Spatial")
    assert diagnostics["spatial_block_count"] >= 2
    assert diagnostics["valid_prior_training_count"] == len(xy)

def test_localization_sweep_defaults_and_csv_comparison(tmp_path):
    module = _load_localization_sweep()
    assert module.parse_counts("10,11,12,13,14,15") == [10, 11, 12, 13, 14, 15]

    rows = []
    station_rows = []
    for count in range(10, 16):
        errors = np.array([30.0 - count, 25.0 - 0.5 * count, 18.0], dtype=float)
        rows.append({
            "algorithm": "DP-PGRSL",
            "station_count": 3,
            "requested_points_per_station": count,
            "selected_points_min": count,
            "selected_points_max": count,
            "mean_error_m": float(errors.mean()),
            "median_error_m": float(np.median(errors)),
            "rmse_m": float(np.sqrt(np.mean(errors ** 2))),
            "p75_error_m": float(np.quantile(errors, 0.75)),
            "p90_error_m": float(np.quantile(errors, 0.90)),
            "p95_error_m": float(np.quantile(errors, 0.95)),
            "max_error_m": float(errors.max()),
            "within_20m_count": int(np.sum(errors <= 20)),
            "within_20m_percent": float(100 * np.mean(errors <= 20)),
            "within_50m_count": 3,
            "within_50m_percent": 100.0,
            "within_100m_count": 3,
            "within_100m_percent": 100.0,
            "within_200m_count": 3,
            "within_200m_percent": 100.0,
        })
        for station_id, error in enumerate(errors, start=1):
            station_rows.append({
                "station_id": station_id,
                "point_count": count,
                "horizontal_error_m": float(error),
            })

    module.save_comparison_outputs(
        tmp_path,
        pd.DataFrame(rows),
        pd.DataFrame(station_rows),
        dpi=50,
        save_figures=False,
    )
    assert (tmp_path / "localization_multicount_total_comparison_table.csv").is_file()
    assert (tmp_path / "localization_multicount_station_errors_wide.csv").is_file()
