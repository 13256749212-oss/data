from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RECON_ROOT = ROOT / "workflows" / "reconstruction"
if str(RECON_ROOT) not in sys.path:
    sys.path.insert(0, str(RECON_ROOT))

from radio_reconstruction.plotting import (
    add_building_outlines,
    plot_clean_map,
    plot_map_with_training_points,
)


def _outline_segments() -> list[np.ndarray]:
    return [
        np.asarray(
            [
                [-120.0, -80.0],
                [-40.0, -80.0],
                [-40.0, 10.0],
                [-120.0, 10.0],
                [-120.0, -80.0],
            ],
            dtype=float,
        )
    ]


def test_building_outline_helper_is_defined_and_callable():
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots()
    try:
        add_building_outlines(ax, _outline_segments())
        assert len(ax.collections) == 1
    finally:
        plt.close(fig)


def test_reconstruction_map_plot_functions_execute_and_write_high_resolution_square_png(tmp_path: Path):
    rsrp = np.linspace(-120.0, -40.0, 512 * 512, dtype=float).reshape(512, 512)
    extent = [-256.0, 256.0, -256.0, 256.0]
    clean = tmp_path / "clean.png"
    with_points = tmp_path / "with_points.png"

    plot_clean_map(
        output_path=clean,
        rsrp_map=rsrp,
        extent=extent,
        outline_segments=_outline_segments(),
        tx_xy=(0.0, 0.0),
        method_label="smoke",
        station_id=3,
        pci=558,
        rmse_db=8.0,
        training_count=10,
    )
    plot_map_with_training_points(
        output_path=with_points,
        rsrp_map=rsrp,
        extent=extent,
        outline_segments=_outline_segments(),
        tx_xy=(0.0, 0.0),
        training_xy=np.asarray([[-100.0, -90.0], [80.0, 110.0]], dtype=float),
        method_label="smoke",
        station_id=3,
        pci=558,
        training_count=2,
    )

    assert Image.open(clean).size == (7480, 7480)
    assert Image.open(with_points).size == (7480, 7480)
