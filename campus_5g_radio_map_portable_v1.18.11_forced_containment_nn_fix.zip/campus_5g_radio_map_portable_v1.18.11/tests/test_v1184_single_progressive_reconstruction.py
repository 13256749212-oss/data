from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"


def _load():
    spec = importlib.util.spec_from_file_location("recon_v1184", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def test_progressive_selector_is_deterministic_nested_and_rsrp_independent():
    r = _load()
    gx, gy = np.meshgrid(np.arange(10.0), np.arange(10.0))
    measured = pd.DataFrame({
        "x_m": gx.ravel()[::5],
        "y_m": gy.ravel()[::5],
        "measured_rsrp_dbm": np.linspace(-110.0, -60.0, len(gx.ravel()[::5])),
    })
    mask = np.ones((10, 10), dtype=bool)
    a = r.progressive_coverage_nested_ranking(measured, np.arange(10.0), np.arange(10.0), mask, 12)
    changed = measured.copy()
    changed["measured_rsrp_dbm"] = changed["measured_rsrp_dbm"].iloc[::-1].to_numpy()
    b = r.progressive_coverage_nested_ranking(changed, np.arange(10.0), np.arange(10.0), mask, 12)
    assert a[["x_m", "y_m"]].equals(b[["x_m", "y_m"]])
    assert set(map(tuple, a.iloc[:6][["x_m", "y_m"]].to_numpy())).issubset(
        set(map(tuple, a.iloc[:12][["x_m", "y_m"]].to_numpy()))
    )
    assert a["selection_method"].eq("single_progressive_geometry_kcenter").all()


def test_single_run_tables_do_not_average_trials():
    r = _load()
    rows = []
    for pct in [1, 2]:
        for variant, sim, rmse in [
            ("without_simulation", False, 20.0 - pct),
            ("with_simulation", True, 17.0 - pct),
        ]:
            rows.append({
                "sampling_percent": pct,
                "selected_measured_point_count": pct * 10,
                "total_eligible_measured_points": 1000,
                "reference_valid_outdoor_cell_count": 200000,
                "selection_mode": "progressive-coverage",
                "variant": variant,
                "simulation_data_used": sim,
                "rmse_db": rmse,
                "mae_db": rmse - 2,
                "bias_pred_minus_reference_db": 0.0,
                "rmse_unsampled_db": rmse + 0.1,
                "mae_unsampled_db": rmse - 1.9,
            })
    paired, long = r._single_run_tables(pd.DataFrame(rows))
    assert paired.loc[0, "rmse_db_without_simulation"] == 19.0
    assert paired.loc[0, "rmse_db_with_simulation"] == 16.0
    assert not any("std" in c.lower() for c in paired.columns)
    assert len(long) == 4


def test_formal_source_is_single_run_and_not_best_trial_selected():
    text = MOD.read_text(encoding="utf-8")
    formal = text[text.index("def main() -> int:"):]
    assert "progressive_coverage_nested_ranking" in formal
    assert "for trial_id in range" not in formal
    assert "best_trial_map_selection_used\": False" in formal
    assert "multi_trial_average_used\": False" in formal
