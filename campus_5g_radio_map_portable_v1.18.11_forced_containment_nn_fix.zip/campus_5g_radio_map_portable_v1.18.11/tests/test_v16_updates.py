from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RECON_ROOT = ROOT / "workflows" / "reconstruction"
if str(RECON_ROOT) not in sys.path:
    sys.path.insert(0, str(RECON_ROOT))

from radio_reconstruction.methods import (
    RTExternalDriftKrigingReconstructor,
    RTMeanMaternGPRReconstructor,
)


class DummyPrior:
    source_path = Path("dummy_prior.npz")
    selected_key = "rsrp_dbm"
    metadata = {"finite_fraction": 1.0}

    @staticmethod
    def sample(xy):
        xy = np.asarray(xy, dtype=float)
        return -88.0 + 0.022 * xy[:, 0] - 0.015 * xy[:, 1]


def _load_localization_sweep():
    path = ROOT / "workflows" / "localization" / "run_27stations_localization_multicount.py"
    spec = importlib.util.spec_from_file_location("loc_sweep_v16", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_rt_ked_and_rt_mean_gpr_return_finite_predictions():
    rng = np.random.default_rng(1601)
    xy = rng.uniform(-180, 180, size=(24, 2))
    prior = DummyPrior.sample(xy)
    values = 0.62 * prior - 28.0 + 3.0 * np.sin(xy[:, 0] / 80.0) + rng.normal(0, 0.3, len(xy))
    query = rng.uniform(-170, 170, size=(35, 2))

    ked = RTExternalDriftKrigingReconstructor(DummyPrior()).fit(xy, values)
    pred_ked, std_ked = ked.predict(query, return_std=True)
    assert np.isfinite(pred_ked).all()
    assert np.isfinite(std_ked).all()
    assert ked.valid_prior_training_count == len(xy)
    assert 0.20 <= ked.affine_a <= 1.80

    gpr = RTMeanMaternGPRReconstructor(
        DummyPrior(), random_seed=17, optimizer_restarts=0
    ).fit(xy, values)
    pred_gpr, std_gpr = gpr.predict(query, return_std=True)
    assert np.isfinite(pred_gpr).all()
    assert np.isfinite(std_gpr).all()
    assert gpr.valid_prior_training_count == len(xy)
    assert gpr.diagnostics["algorithm_name"].startswith("Sionna RT Mean-Function")


def test_cross_count_stabilizer_limits_only_uncertain_large_drift():
    m = _load_localization_sweep()
    rows = []
    for sid in [1, 2]:
        for k in range(10, 16):
            if sid == 1:
                x, y, unc = 10.0 + 5.0 * (k - 10), 20.0, 20.0
            else:
                x, y, unc = 100.0 + 30.0 * (k - 10), 50.0, 90.0
            rows.append({
                "station_id": sid,
                "point_count": k,
                "selected_point_count": k,
                "predicted_x_m": x,
                "predicted_y_m": y,
                "true_x_m": 0.0,
                "true_y_m": 0.0,
                "east_error_m": x,
                "north_error_m": y,
                "horizontal_error_m": float(np.hypot(x, y)),
                "uncertainty_radius_p90_m": unc,
                "point_spread_m": 200.0,
                "quality_flag": "ok",
            })
    out = m.stabilize_cross_count_predictions(pd.DataFrame(rows))
    stable = out[out.station_id == 1]
    drifting = out[out.station_id == 2]
    assert not stable.cross_count_stabilized.any()
    assert drifting.cross_count_stabilized.iloc[3:].any()
    # Reference at x=100, drift limit=max(60, 40)=60 m.
    final = drifting[drifting.point_count == 15].iloc[0]
    assert abs(final.predicted_x_m - 160.0) < 1e-6
    assert "cross_count_drift_limited" in final.quality_flag


def test_stabilized_summary_reports_stabilized_count():
    m = _load_localization_sweep()
    frame = pd.DataFrame({
        "station_id": [1, 2],
        "point_count": [10, 10],
        "selected_point_count": [10, 10],
        "horizontal_error_m": [10.0, 30.0],
        "quality_flag": ["ok", "cross_count_drift_limited"],
        "cross_count_stabilized": [False, True],
    })
    summary = m.summarize_stabilized_results(frame)
    assert int(summary.loc[0, "cross_count_stabilized_count"]) == 1
    assert abs(float(summary.loc[0, "rmse_m"]) - np.sqrt(500.0)) < 1e-9
