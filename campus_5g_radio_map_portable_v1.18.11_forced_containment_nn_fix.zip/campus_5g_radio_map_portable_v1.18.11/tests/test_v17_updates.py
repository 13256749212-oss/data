from pathlib import Path
import sys, importlib.util
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
RR=ROOT/'workflows'/'reconstruction'
sys.path.insert(0,str(RR))
from radio_reconstruction.methods import DensityAdaptiveGuardedEnsembleReconstructor
class Prior:
    source_path=Path('dummy.npz'); selected_key='rsrp_dbm'; metadata={'finite_fraction':1.0}
    def sample(self,xy):
        xy=np.asarray(xy,float); return -90+0.02*xy[:,0]-0.01*xy[:,1]
def test_dage_regime_selection_and_finite_predictions():
    rng=np.random.default_rng(17)
    for n,expected in [(10,'rt_external_drift_kriging'),(20,'ordinary_kriging'),(40,'adaptive_matern_gpr')]:
        xy=rng.uniform(-100,100,(n,2)); y=0.6*Prior().sample(xy)-30+rng.normal(0,1,n)
        m=DensityAdaptiveGuardedEnsembleReconstructor(Prior(),random_seed=3).fit(xy,y)
        assert m.selected_model_name==expected
        pred,std=m.predict(rng.uniform(-80,80,(12,2)),return_std=True)
        assert np.isfinite(pred).all() and np.isfinite(std).all()
def test_v17_model_dominant_weighting_text_present():
    text=(ROOT/'workflows'/'localization'/'run_27stations_sparse_localization_v2.py').read_text(encoding='utf-8')
    assert ('DP-PGRSL-v1.8' in text) or ('DP-PPRSL-v1.10' in text)
    assert ('ceiling = 0.90 if omni else 0.94' in text) or ('ceiling = 0.97 if omni else 0.995' in text)
