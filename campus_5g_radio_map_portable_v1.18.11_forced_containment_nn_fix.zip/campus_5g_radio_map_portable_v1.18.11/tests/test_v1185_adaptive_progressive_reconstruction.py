from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"


def _load():
    spec = importlib.util.spec_from_file_location("recon_v1185", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _frame(nx: int = 14, ny: int = 10) -> pd.DataFrame:
    gx, gy = np.meshgrid(np.arange(nx, dtype=float), np.arange(ny, dtype=float))
    x = gx.ravel()
    y = gy.ravel()
    # Smooth but nontrivial synthetic radio field.
    rsrp = -72.0 - 0.75 * x - 0.35 * y + 3.5 * np.sin(x / 2.7) - 2.0 * np.cos(y / 2.2)
    return pd.DataFrame({"x_m": x, "y_m": y, "measured_rsrp_dbm": rsrp})


def test_initial_stage_is_geometry_only():
    r = _load()
    a = _frame()
    b = a.copy()
    b["measured_rsrp_dbm"] = b["measured_rsrp_dbm"].iloc[::-1].to_numpy()
    ra = r.adaptive_progressive_nested_ranking(a, max_count=28, initial_count=10, gradient_weight=0.5)
    rb = r.adaptive_progressive_nested_ranking(b, max_count=28, initial_count=10, gradient_weight=0.5)
    assert ra.iloc[:10][["x_m", "y_m"]].equals(rb.iloc[:10][["x_m", "y_m"]])


def test_unselected_candidate_rsrp_does_not_affect_next_choice():
    r = _load()
    a = _frame()
    ra = r.adaptive_progressive_nested_ranking(a, max_count=24, initial_count=10, gradient_weight=0.5)
    selected_coords = set(map(tuple, ra.iloc[:24][["x_m", "y_m"]].to_numpy()))

    b = a.copy()
    unselected = [i for i, row in b.iterrows() if (float(row.x_m), float(row.y_m)) not in selected_coords]
    # Alter only points that were never selected in the original 24-point path.
    b.loc[unselected, "measured_rsrp_dbm"] += 50.0
    rb = r.adaptive_progressive_nested_ranking(b, max_count=24, initial_count=10, gradient_weight=0.5)
    assert ra[["x_m", "y_m"]].equals(rb[["x_m", "y_m"]])


def test_adaptive_sequence_is_nested_and_single_path():
    r = _load()
    frame = _frame()
    ranked = r.adaptive_progressive_nested_ranking(frame, max_count=30, initial_count=10, gradient_weight=0.5)
    assert len(ranked) == 30
    assert ranked["adaptive_rank"].tolist() == list(range(1, 31))
    first = set(map(tuple, ranked.iloc[:10][["x_m", "y_m"]].to_numpy()))
    later = set(map(tuple, ranked.iloc[:30][["x_m", "y_m"]].to_numpy()))
    assert first.issubset(later)
    assert ranked["selection_method"].eq("adaptive_progressive_selected_rsrp_gradient").all()


def test_synthetic_nn_error_has_expected_decreasing_density_trend():
    r = _load()
    frame = _frame(nx=18, ny=12)
    ranked = r.adaptive_progressive_nested_ranking(frame, max_count=44, initial_count=8, gradient_weight=0.5)
    all_xy = frame[["x_m", "y_m"]].to_numpy(dtype=float)
    all_y = frame["measured_rsrp_dbm"].to_numpy(dtype=float)
    coord_to_y = {(float(x), float(y)): float(v) for (x, y), v in zip(all_xy, all_y)}

    rmses = []
    for k in [8, 16, 24, 32, 44]:
        sel_xy = ranked.iloc[:k][["x_m", "y_m"]].to_numpy(dtype=float)
        sel_y = np.asarray([coord_to_y[(float(x), float(y))] for x, y in sel_xy], dtype=float)
        tree = cKDTree(sel_xy)
        _, idx = tree.query(all_xy, k=1)
        pred = sel_y[np.asarray(idx, dtype=int)]
        rmses.append(float(np.sqrt(np.mean((pred - all_y) ** 2))))
    assert rmses[-1] < rmses[0]
    # This regression test checks the intended trend on a smooth field.  It is
    # not an RMSE post-processing rule and does not imply a mathematical theorem.
    assert sum(np.diff(rmses) > 1e-12) <= 1
