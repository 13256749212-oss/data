from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"
RECON_DIR = ROOT / "workflows" / "reconstruction"
if str(RECON_DIR) not in sys.path:
    sys.path.insert(0, str(RECON_DIR))


def _load():
    spec = importlib.util.spec_from_file_location("recon_v1186", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _frame(nx: int = 18, ny: int = 12) -> pd.DataFrame:
    gx, gy = np.meshgrid(np.arange(nx, dtype=float), np.arange(ny, dtype=float))
    return pd.DataFrame({
        "x_m": gx.ravel(),
        "y_m": gy.ravel(),
        "measured_rsrp_dbm": (-80 + 0.3 * gx.ravel() - 0.2 * gy.ravel()),
        "ix": gx.ravel().astype(int),
        "iy": gy.ravel().astype(int),
    })


def test_stable_spatial_selection_does_not_use_rsrp_amplitude():
    r = _load()
    frame_a = _frame()
    frame_b = frame_a.copy()
    frame_b["measured_rsrp_dbm"] = np.linspace(-119, -41, len(frame_b))[::-1]
    x_axis = np.arange(18, dtype=float)
    y_axis = np.arange(12, dtype=float)
    mask = np.ones((12, 18), dtype=bool)
    sets_a, audit_a = r.stable_spatial_percentage_sets(frame_a, x_axis, y_axis, mask, [1, 5, 10])
    sets_b, audit_b = r.stable_spatial_percentage_sets(frame_b, x_axis, y_axis, mask, [1, 5, 10])
    for pct in [1, 5, 10]:
        a = sets_a[pct][["x_m", "y_m"]].sort_values(["x_m", "y_m"]).reset_index(drop=True)
        b = sets_b[pct][["x_m", "y_m"]].sort_values(["x_m", "y_m"]).reset_index(drop=True)
        pd.testing.assert_frame_equal(a, b)
    assert not audit_a["selection_uses_reference_rsrp"].any()
    assert not audit_a["selection_uses_measured_rsrp"].any()
    assert not audit_a["selection_uses_simulation_rsrp"].any()


def test_stable_spatial_percentage_counts_are_exact():
    r = _load()
    frame = _frame()
    x_axis = np.arange(18, dtype=float)
    y_axis = np.arange(12, dtype=float)
    mask = np.ones((12, 18), dtype=bool)
    percentages = [1, 2, 5, 10]
    sets, _ = r.stable_spatial_percentage_sets(frame, x_axis, y_axis, mask, percentages)
    n = len(frame)
    for pct in percentages:
        expected = max(1, int(np.ceil(n * pct / 100.0)))
        assert len(sets[pct]) == expected


class _LinearPrior:
    def sample(self, xy: np.ndarray) -> np.ndarray:
        xy = np.asarray(xy, dtype=float)
        return -100.0 + 0.5 * xy[:, 0] - 0.25 * xy[:, 1]


def test_calibrated_sionna_residual_nn_recovers_affine_prior_relation():
    r = _load()
    prior = _LinearPrior()
    train_xy = np.array([[0, 0], [10, 0], [0, 10], [10, 10], [5, 5], [15, 5]], dtype=float)
    prior_train = prior.sample(train_xy)
    train_y = 0.65 * prior_train - 31.0
    query_xy = np.array([[2, 3], [8, 6], [14, 4]], dtype=float)
    baseline = np.full(len(query_xy), -90.0)
    pred, diag = r.simulation_residual_nearest_neighbor(
        prior=prior,
        train_xy=train_xy,
        train_y=train_y,
        query_xy=query_xy,
        baseline_prediction=baseline,
    )
    expected = 0.65 * prior.sample(query_xy) - 31.0
    assert np.max(np.abs(pred - expected)) < 0.02
    assert abs(diag["affine_prior_slope"] - 0.65) < 0.02
    assert abs(diag["affine_prior_intercept_db"] + 31.0) < 2.0
