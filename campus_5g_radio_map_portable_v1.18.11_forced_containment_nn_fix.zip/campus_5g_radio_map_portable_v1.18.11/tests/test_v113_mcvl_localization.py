from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def _load():
    path = ROOT / 'workflows/localization/run_27stations_multicandidate_cv_localization.py'
    spec = importlib.util.spec_from_file_location('mcvl_v113_test', path)
    m = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent)); sys.modules['mcvl_v113_test'] = m
    try:
        spec.loader.exec_module(m)
    finally:
        sys.path.pop(0)
    return m


def _synthetic(m, tx, angles, points, noise, seed):
    rng = np.random.default_rng(seed)
    rows = []
    for i, p in enumerate(points):
        p = np.asarray(p, float)
        bearing = np.arctan2(p[1] - tx[1], p[0] - tx[0])
        d = np.sqrt(np.sum((p - tx) ** 2) + m.VERTICAL_SEPARATION_M ** 2)
        row = {'x_m': p[0], 'y_m': p[1], 'z_m': 1.5, 'selection_rank': i + 1}
        for j, a in enumerate(angles, 1):
            gain = m.sector_gain_db(np.array([bearing - a]))[0]
            row[f'rsrp_s{j}'] = -25 - 27 * np.log10(d) + gain + rng.normal(0, noise)
            row[f'pci_s{j}'] = 500 + j
        rows.append(row)
    return pd.DataFrame(rows)


def test_random_points_is_uniform_seeded():
    m = _load(); n = 30
    df = pd.DataFrame({
        'x_m': np.arange(n, dtype=float), 'y_m': np.arange(n, dtype=float), 'z_m': 1.5,
        'rsrp_s1': np.where(np.arange(n) % 2 == 0, -80., np.nan),
        'rsrp_s2': np.where(np.arange(n) % 3 == 0, -82., np.nan),
        'rsrp_s3': np.where(np.arange(n) % 5 == 0, -84., np.nan),
    })
    a = m.random_points(df, 10, 123); b = m.random_points(df, 10, 123); c = m.random_points(df, 10, 124)
    assert a[['x_m','y_m']].equals(b[['x_m','y_m']])
    assert not a[['x_m','y_m']].equals(c[['x_m','y_m']])
    assert len(a) == 10


def test_mcvl_recovers_three_sector_synthetic_site():
    m = _load(); tx = np.array([50., -30.]); angles = np.array([0., 2*np.pi/3, -2*np.pi/3]); rng = np.random.default_rng(4)
    points = []
    for i in range(15):
        theta = angles[i % 3] + rng.normal(0, 0.42); r = rng.uniform(80, 300)
        points.append(tx + r*np.array([np.cos(theta), np.sin(theta)]) + rng.normal(0, 8, 2))
    df = _synthetic(m, tx, angles, points, 2.0, 44)
    sol = m.solve(df, angles, True, False, (-600,600,-600,600))
    assert sol['solver_mode'] == 'multi_candidate_lolo_cross_validated'
    assert sol['candidate_count'] >= 5
    assert np.isfinite(sol['cv_rmse_db'])
    assert np.linalg.norm(sol['final_xy'] - tx) < 45.0


def test_mcvl_handles_one_sided_road_geometry():
    m = _load(); tx = np.array([0., 0.]); angles = np.array([0., 2*np.pi/3, -2*np.pi/3]); rng = np.random.default_rng(18)
    points = [np.array([rng.uniform(80,420), rng.uniform(-100,100)]) for _ in range(15)]
    df = _synthetic(m, tx, angles, points, 3.0, 81)
    sol = m.solve(df, angles, True, False, (-600,600,-600,600))
    assert np.isfinite(sol['final_xy']).all()
    assert np.linalg.norm(sol['final_xy'] - tx) < 90.0


def test_mcvl_solution_has_cv_diagnostics_not_truth_inputs():
    m = _load(); angles = np.array([0., 2*np.pi/3, -2*np.pi/3]); tx = np.array([10., 20.]); rng = np.random.default_rng(5)
    points = [tx + rng.uniform(80,250)*np.array([np.cos(angles[i%3]), np.sin(angles[i%3])]) + rng.normal(0,5,2) for i in range(12)]
    df = _synthetic(m, tx, angles, points, 2.0, 77)
    sol = m.solve(df, angles, True, False, (-500,500,-500,500))
    for key in ['cv_rmse_db','candidate_score_gap','top5_candidate_spread_m','validation_pathloss_exponent']:
        assert key in sol
    assert 'true_x_m' not in sol and 'true_y_m' not in sol
