from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / "workflows" / "reconstruction" / "run_reconstruction.py"
RECON_DIR = ROOT / "workflows" / "reconstruction"
if str(RECON_DIR) not in sys.path:
    sys.path.insert(0, str(RECON_DIR))


def _load():
    spec = importlib.util.spec_from_file_location("recon_v1188", MOD)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _frame(nx: int = 24, ny: int = 16) -> pd.DataFrame:
    gx, gy = np.meshgrid(np.arange(nx, dtype=float), np.arange(ny, dtype=float))
    keep = ((gy.astype(int) % 3) == 0) | ((gx.astype(int) % 5) == 0)
    x = gx[keep].ravel()
    y = gy[keep].ravel()
    rsrp = -78.0 + 5.0 * np.sin(x / 3.0) - 0.7 * y + 2.0 * np.cos(y / 2.5)
    return pd.DataFrame({
        "x_m": x,
        "y_m": y,
        "measured_rsrp_dbm": rsrp,
        "ix": x.astype(int),
        "iy": y.astype(int),
    })


def test_v1188_adaptive_domain_nested_mode_remains_available():
    run_pipeline = (ROOT / "run_pipeline.py").read_text(encoding="utf-8")
    recon = MOD.read_text(encoding="utf-8")
    assert '"adaptive-domain-nested"' in run_pipeline
    assert '"adaptive-domain-nested"' in recon


def test_adaptive_domain_selector_is_strict_nested():
    r = _load()
    frame = _frame()
    mask = np.ones((16, 24), dtype=bool)
    n = len(frame)
    first = max(1, int(np.ceil(n * 0.01)))
    last = max(first, int(np.ceil(n * 0.10)))
    ranked, audit = r.adaptive_domain_nested_ranking(
        frame, np.arange(24, dtype=float), np.arange(16, dtype=float), mask,
        max_count=last, initial_count=first, gradient_weight=0.75,
    )
    assert len(ranked) == last
    assert ranked["adaptive_domain_rank"].tolist() == list(range(1, last + 1))
    assert audit["sampling_sets_nested"].all()
    for a, b in zip(range(first, last), range(first + 1, last + 1)):
        sa = set(map(tuple, ranked.iloc[:a][["x_m", "y_m"]].to_numpy()))
        sb = set(map(tuple, ranked.iloc[:b][["x_m", "y_m"]].to_numpy()))
        assert sa.issubset(sb)


def test_initial_subset_is_geometry_only_and_unselected_labels_are_not_read():
    r = _load()
    a = _frame()
    mask = np.ones((16, 24), dtype=bool)
    n = len(a)
    first = max(2, int(np.ceil(n * 0.02)))
    last = max(first + 8, int(np.ceil(n * 0.10)))
    ra, _ = r.adaptive_domain_nested_ranking(
        a, np.arange(24, dtype=float), np.arange(16, dtype=float), mask,
        max_count=last, initial_count=first, gradient_weight=0.75,
    )

    b = a.copy()
    # Initial subset must not depend on any RSRP values.
    b["measured_rsrp_dbm"] = np.linspace(-119.0, -41.0, len(b))[::-1]
    rb, _ = r.adaptive_domain_nested_ranking(
        b, np.arange(24, dtype=float), np.arange(16, dtype=float), mask,
        max_count=first, initial_count=first, gradient_weight=0.75,
    )
    pd.testing.assert_frame_equal(
        ra.iloc[:first][["x_m", "y_m"]].reset_index(drop=True),
        rb.iloc[:first][["x_m", "y_m"]].reset_index(drop=True),
    )

    # Alter only candidates never selected by the original path. Their labels
    # must not change any acquisition choice because the selector never reads an
    # unselected candidate's RSRP.
    selected_coords = set(map(tuple, ra[["x_m", "y_m"]].to_numpy()))
    c = a.copy()
    unselected = [
        i for i, row in c.iterrows()
        if (float(row.x_m), float(row.y_m)) not in selected_coords
    ]
    c.loc[unselected, "measured_rsrp_dbm"] += 60.0
    rc, _ = r.adaptive_domain_nested_ranking(
        c, np.arange(24, dtype=float), np.arange(16, dtype=float), mask,
        max_count=last, initial_count=first, gradient_weight=0.75,
    )
    pd.testing.assert_frame_equal(
        ra[["x_m", "y_m"]].reset_index(drop=True),
        rc[["x_m", "y_m"]].reset_index(drop=True),
    )


def test_full_domain_geometry_improves_as_points_are_added():
    r = _load()
    frame = _frame()
    mask = np.ones((16, 24), dtype=bool)
    n = len(frame)
    first = max(1, int(np.ceil(n * 0.01)))
    last = max(first, int(np.ceil(n * 0.10)))
    _, audit = r.adaptive_domain_nested_ranking(
        frame, np.arange(24, dtype=float), np.arange(16, dtype=float), mask,
        max_count=last, initial_count=first, gradient_weight=0.75,
    )
    vals = audit["domain_mean_squared_nearest_distance_m2"].to_numpy(float)
    # Adding a new site can never worsen nearest-distance coverage for a nested set.
    assert np.all(np.diff(vals) <= 1e-10)
    assert vals[-1] < vals[0]
    assert not audit["selection_uses_reference_rsrp"].any()
    assert not audit["selection_uses_unselected_measured_rsrp"].any()
    assert not audit["selection_uses_simulation_rsrp"].any()
