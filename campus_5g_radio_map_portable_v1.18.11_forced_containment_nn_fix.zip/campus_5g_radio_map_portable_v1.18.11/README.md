# 校园 5G 无线电地图项目便携运行包

版本：1.18.11

本包保留项目的统一入口、核心工作流、配置、场景模型、原始/对齐/正式处理数据、Windows 辅助脚本与测试代码。原项目源码未作修改。实验结果、缓存、IDE 文件、论文文档与历史图表未打包；程序运行后会在本机重新创建 `outputs/`。

## 1. 运行环境

推荐配置：

- Windows 10/11（项目也以 Python 相对路径组织，可在其他系统尝试运行）
- Miniconda 或 Anaconda
- Python 3.10
- 需要射线追踪时，使用支持 CUDA 的 NVIDIA GPU 和与驱动匹配的运行环境
- 完整 27 站校准、4000×3000 联合地图和高分辨率绘图需要较多时间、显存、内存与磁盘空间

建议把解压目录放在较短的纯英文路径，例如 `D:\campus_5g_radio_map`，并始终从解压后的项目根目录运行命令。

## 2. 安装

打开 Anaconda Prompt 或 PowerShell，进入本 README 所在目录：

```powershell
conda env create -f environment.yml
conda activate sionna_env
python -c "import numpy, pandas, scipy, trimesh, pyproj, sionna; print('environment OK')"
```

如果同名环境已经存在，可更新环境：

```powershell
conda env update -f environment.yml --prune
conda activate sionna_env
```

不使用 Conda 时，也可在 Python 3.10 虚拟环境中安装：

```powershell
python -m pip install -r requirements.txt
python -m pip install sionna==1.2.2
```

## 3. 首次检查

```powershell
python run_pipeline.py --help
python run_pipeline.py check
```

本包已经包含三份正式处理表，因此进行定位、校准等实验时通常不需要先重做数据预处理：

- `data/processed/cell_pci_rsrp_long_27stations.csv`
- `data/processed/cell_pci_rsrp_1m_calibration.csv`
- `data/processed/cell_pci_rsrp_2p77m_localization.csv`

## 4. 数据预处理（需要从原始 CSV 重建时）

完整执行坐标对齐、多 PCI–RSRP 展开和正式表生成：

```powershell
python run_pipeline.py prepare-data
```

强制重建已经存在的对齐结果：

```powershell
python run_pipeline.py prepare-data --force
```

也可以逐步运行：

```powershell
python run_pipeline.py align
python run_pipeline.py extract
python run_pipeline.py preprocess
```

## 5. 参数校准与无线电地图

先用单站快速模式验证 Sionna RT、GPU 和场景加载：

```powershell
python run_pipeline.py calibrate --stations 3 --quick
```

执行全部 27 站校准：

```powershell
python run_pipeline.py calibrate --stations all
```

校准完成后，可导出 DEM 地图并比较 DEM 与固定高度平面：

```powershell
python run_pipeline.py export-dem --stations all
python run_pipeline.py compare-surfaces --stations all --surface-mode both
```

生成联合地图前建议先做参数与资源检查：

```powershell
python run_pipeline.py export-joint-map --dry-run
python run_pipeline.py export-joint-map --quick
```

完整联合地图：

```powershell
python run_pipeline.py export-joint-map
python run_pipeline.py compare-joint-map
```

## 6. 定位与重构

### 6.1 定位：严格双分支，只输出两项 RMSE

正式定位实验现在严格限定为两个分支，并且两个分支在同一 trial、同一基站、同一点数下使用**完全相同的随机实测接收位置**：

1. **Measurement-only**：只使用所选接收位置的实测 PCI–RSRP 和接收位置坐标进行定位。正式双分支实验中不加载 Sionna RSRP、不加载 Sionna 地图峰值/中心/发射机坐标，也不加载校准后的方向先验。
2. **Measurement–simulation**：使用与 Measurement-only 完全相同的实测接收位置和实测 PCI–RSRP，并额外在这些接收位置读取固定、预先生成的 Sionna RT PCI–RSRP，形成共址的 measured + simulated 两个观测通道。仿真地图的峰值、中心、边界和发射机元数据不参与候选位置生成。

真值基站坐标在两个分支的定位结果全部形成以后才用于计算水平定位误差。正式结果表中只保留用户要求的两个指标：

- `Measurement-only RMSE (m)`
- `Measurement–simulation RMSE (m)`

10--15 点正式实验：

```powershell
python run_pipeline.py localize-sweep --point-counts 10,11,12,13,14,15 --random-trials 10
```

输出目录默认：

```text
outputs/localization_two_branch_rmse_only/
```

正式输出只有：

```text
localization_rmse_comparison.csv
```

其列为：

```text
Receiver locations per station
Measurement-only RMSE (m)
Measurement–simulation RMSE (m)
```

不再输出 mean、median、P90、P95、within-50 m、within-100 m、CV RMSE、candidate gap、improved-percent、robust consensus 等额外指标。

单一点数也使用同一严格双分支协议，例如：

```powershell
python run_pipeline.py localize --points-per-station 10 --random-trials 10
```

### 6.2 重构

重构仍保持 v1.18.0 的完整 512 m × 512 m 有效栅格评价和最近邻双分支定义：

```powershell
python run_pipeline.py reconstruct --station-id 3 --pci 558 --simulation-mode compare
```

## 7. 可视化与测试

```powershell
python run_pipeline.py visualize-measurements
python run_pipeline.py plot-output-structure
python run_pipeline.py test
```

Windows 下测试套件若仅出现路径分隔符（`/` 与 `\`）断言差异，属于测试文本的跨平台差异，不影响工作流运行。判断运行环境是否可用，应同时以 `python run_pipeline.py check` 和实际单站快速校准为准。

## 8. 目录说明

- `run_pipeline.py`：统一命令入口
- `check_project_layout.py`：项目数据和路径检查
- `workflows/`：预处理、校准、地图、定位、重构、评估与可视化代码
- `config/`：基站、PCI、场景对齐和坐标配置
- `assets/`：地面和校园场景 PLY
- `data/raw_measurements/`：12 份原始测量 CSV
- `data/aligned_measurements/`：坐标对齐后的 CSV
- `data/processed/`：三份正式处理数据表
- `scripts/windows/`：Windows 批处理入口；使用前先激活 `sionna_env`
- `tests/`：轻量测试
- `outputs/`：运行后生成，便携包内刻意不包含

所有命令默认从项目根目录读写相对路径。移动到另一台电脑后，不需要修改源码中的项目根目录；只需重新创建 Python 环境，并从新的解压目录运行命令。


## v1.18.0 reconstruction correction

The formal reconstruction experiment has been restored to the original full-radio-map evaluation domain. The primary error is computed on every finite outdoor grid cell of the 512 m × 512 m Measurement-filled reference map, rather than on held-out measured points. The two formal branches are now strictly nearest-neighbor based: measurement-only 1-NN and fixed-Sionna plus 1-NN interpolation of the measured-minus-Sionna residual. Fifty independent nested random trials are averaged directly; no monotonic post-processing or RMSE-based seed selection is applied.


## v1.18.1 localization correction

The formal localization workflow is now a strict paired ablation: Measurement-only uses only the selected measured receiver coordinates and measured PCI-RSRP; Measurement–simulation uses the exact same measurements plus collocated RSRP sampled from fixed pre-generated Sionna RT maps. The formal localization output contains only the two requested RMSE columns. External calibrated direction priors are disabled in this formal comparison so that the only input difference between the branches is the presence of simulation data.

## v1.18.2 localization sparse-Sionna fix

The formal localization comparison remains unchanged: **Measurement-only** uses only the selected measured PCI-RSRP observations, while **Measurement–simulation** uses the exact same selected measured receiver locations plus the fixed pre-generated Sionna RT PCI-RSRP channel. The formal CSV still contains only the receiver-location count and the two requested RMSE columns.

For localization only, the fixed 1 m Sionna map is now sampled by the nearest grid cell rather than bilinear interpolation. Bilinear interpolation could return NaN when any surrounding RT cell was invalid. If a Sionna value is still missing/no-path after nearest-grid sampling, it is treated as a simulation-side lower-censored value at -120 dBm. This uses no measured RSRP and no physical base-station truth, does not drop or replace any selected measured receiver location, and prevents a sparse RT map from causing the M+S branch to fail LOLO validation (e.g. Station 13 `matched=6, valid_LOLO_folds=0`).

## v1.18.4 single progressive reconstruction correction

The formal radio-map reconstruction no longer averages 50 random trials while displaying a separate representative map. Each sampling percentage is reconstructed exactly once, and the RMSE values, saved NPZ files, per-percentage PNG files, and the 1%/5%/10% composite all come from the same single progressive experiment.

The default sampling selector is `progressive-coverage`: one deterministic geometry-only nested ranking is built from measured-point coordinates and the valid outdoor evaluation-domain mask. It does not inspect reference-map RSRP, does not inspect unselected measured RSRP, and does not search seeds using final RMSE. The 1%-10% subsets are strict prefixes of this same ranking. This reduces spatial coverage gaps as the sample count increases and is more suitable for a single nearest-neighbor reconstruction curve than selecting a best map from repeated random trials.

Run:

```powershell
python run_pipeline.py reconstruct --station-id 3 --pci 558 --simulation-mode compare
```

Formal outputs include `reconstruction_single_run_metrics.csv`, `reconstruction_simulation_ablation_comparison.csv`, `reconstruction_trend_audit.md`, `reconstruction_simulation_ablation_rmse.png`, one pair of NPZ/PNG reconstruction maps under every `percent_XX` folder, and `reconstruction_maps_1_5_10.png` generated from those same maps.

## v1.18.5 adaptive-progressive single-run reconstruction

The v1.18.4 result showed a small 9% -> 10% RMSE reversal even though its spatial
coverage distances improved. The cause is the Voronoi reassignment property of
strict 1-nearest-neighbor interpolation rather than an averaging bug.

The default `reconstruct` selector is now `adaptive-progressive`. The first stage
uses geometry-only farthest-point sampling. Later points are chosen from known
candidate coordinates using spatial distance and a signal-gradient proxy computed
**only from measurements already selected at earlier steps**. The selector does
not read reference-map RSRP, Sionna RSRP, or the RSRP of an unselected candidate.
The subsets remain strict nested prefixes and the M/M+S branches use exactly the
same points.

Each percentage still generates exactly one M map and one M+S map, and the CSV
RMSE is calculated from those exact maps over the full 512 m x 512 m valid outdoor
reference domain. There is no multi-trial average, best-seed search, or monotonic
RMSE post-processing.

Run:

```bash
python run_pipeline.py reconstruct --station-id 3 --pci 558 --simulation-mode compare
```

To reproduce the old v1.18.4 geometry-only nested selector, add:

```bash
--selection-mode progressive-coverage
```


## v1.18.6 单次独立空间分层 + 校准 Sionna 残差最近邻重构

本版只修改正式无线电地图重构协议，不改变定位工作流。正式 `reconstruct` 默认使用 `stable-spatial`：1%--10% 每个采样比例分别根据候选实测点坐标与 512 m × 512 m 有效室外区域几何独立生成一套空间分层实测子集；不同采样比例不再强制为同一嵌套前缀。选点不读取 reference-map RSRP、不读取实测 RSRP 幅值、不读取 Sionna RSRP，也不根据最终 RMSE 选择 seed 或采样集合。每个采样比例只生成一次实际无线电地图。

两个正式分支仍保持最近邻法：

- `Measurement-only`：当前比例选中的实测 RSRP 直接进行 1-NN 全图重构。
- `Measurement + simulation`：使用完全相同的实测点，只在这些已选点上稳健拟合 `measured ≈ a × Sionna + b`，再对校准后的 measurement-minus-simulation residual 执行 1-NN；仿真无效栅格回退到纯实测 1-NN。

RMSE 仍按原实验口径，在 512 m × 512 m Measurement-filled reference map 的全部有限室外栅格上计算。没有多次 trial 平均、没有 best-trial 地图、没有 RMSE 单调化后处理。

运行：

```powershell
python run_pipeline.py reconstruct --station-id 3 --pci 558 --simulation-mode compare
```

如需复现旧的严格嵌套几何选点，可显式传入 `--selection-mode progressive-coverage`；正式默认不再使用。


## v1.18.7 严格嵌套单次 1-NN 重构修正

正式重构默认改为 `hierarchical-nested`。1%--10% 不再像 v1.18.6 那样分别重新选择一套测量点，而是先根据实测位置与 512 m × 512 m 有效室外区域几何构造 10% 的全局空间覆盖集合，再通过反向几何消元得到较低采样比例，因此严格满足：

```text
S_1% ⊂ S_2% ⊂ ... ⊂ S_10%
```

每个采样比例仍只生成一次实际无线电地图。两个分支使用完全相同的实测点：

- Measurement-only：纯实测 1-nearest-neighbor；
- Measurement + simulation：相同实测点 + 固定 Sionna RT，使用所选实测点完成稳健仿真趋势校准，并对校准残差执行 1-nearest-neighbor。

点的选择不读取参考地图 RSRP、不读取实测 RSRP 幅值、不读取 Sionna RSRP，也不根据最终 RMSE 选 seed 或做单调化后处理。RMSE/MAE 在整个 512 m × 512 m 有效室外参考栅格上使用原始数值计算；`-120~-40 dBm` 仅作为绘图显示范围，不再在定量评价前执行 `np.clip`。

正式运行：

```powershell
python run_pipeline.py reconstruct --station-id 3 --pci 558 --simulation-mode compare
```

主要新增审计文件：

```text
single_hierarchical_nested_ranking.csv
hierarchical_nested_selection_audit.csv
reconstruction_full_grid_evaluation_audit.csv
reconstruction_trend_audit.md
```


## v1.18.8 reconstruction trend correction

The default reconstruction selector is now `adaptive-domain-nested`. The first sparse subset is selected using geometry only. Later points are added sequentially using two leakage-safe signals: (1) how much full 512 m × 512 m outdoor area a candidate represents geometrically and (2) a local RSRP-gradient proxy computed only from measurements that have already been selected. Unselected measured RSRP, reference-map RSRP, and Sionna RSRP are never used for sampling. The 1%--10% sets remain strict nested prefixes, each percentage generates exactly one map, Measurement-only remains exact 1-NN, and Measurement+simulation uses the same selected points with calibrated Sionna plus residual 1-NN. Quantitative RMSE remains unclipped and is evaluated on the complete valid full-grid reference domain.


## v1.18.10 reconstruction Voronoi-safety correction

The default reconstruction selector is now `voronoi-safe-adaptive-nested`. The reconstruction methods themselves are unchanged: Measurement-only is exact 1-NN and Measurement+simulation uses the identical measured points with selected-data robust affine Sionna alignment plus residual 1-NN. The 1%--10% sets remain strict nested prefixes and each percentage generates exactly one map evaluated on the complete valid 512 m x 512 m grid. The selector addresses the stage-level 1-NN Voronoi takeover mechanism without reading reference-map RSRP, Sionna RSRP, final RMSE, or unselected measured RSRP. When a newly acquired point reveals a large RSRP jump relative to its previous controlling measured neighbour, later acquisitions in the same percentage stage preferentially constrain that local Voronoi region. The last acquisition of each percentage stage is chosen conservatively from a smooth, moderate-takeover candidate pool so a stage is less likely to end on an uncontained high-impact point. No RMSE monotonic post-processing is applied.


## v1.18.11 reconstruction forced-containment correction

本版本仅完善重构选点稳定性，核心重构与评价口径不变：

- Measurement-only：严格 1-NN 最近邻重构。
- Measurement+simulation：相同实测点 + 选中实测内部稳健校准的固定 Sionna RT + residual 1-NN。
- 1%--10% 严格嵌套，每个比例只生成一次地图。
- RMSE 使用完整 512 m × 512 m 有效室外参考栅格；定量值不做显示范围 clipping。
- 选点不读取 reference RSRP、未采样实测 RSRP、Sionna RSRP 或最终 RMSE。

v1.18.10 已能检测高 RSRP 跳变，但 containment 只是软加权，因此实际结果中 rank 67 的约 17.3 dB 跳变后，后续点仍可能继续以 `coverage_transition` 进入，未真正限制其 Voronoi 接管。v1.18.11 改为 **forced containment**：一旦已获得的新实测点满足高跳变条件，且当前采样阶段仍有预算，下一采样槽优先强制选择该点附近的几何约束点；强跳变在预算允许时连续配置两个不同方向的约束点。约束点选择只使用坐标、已知有效域和已经观测到的跳变，不读取任何未采样标签。

该机制用于降低单次严格 1-NN 在新增高跳变样本时的大面积 Voronoi 重划分风险，但不会读取参考图并强制 RMSE 单调。
